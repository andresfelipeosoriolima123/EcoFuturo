<?php
// Archivo: logica/ActividadController.php
require_once __DIR__ . '/../config/auth.php';
requireRole(2);
require_once __DIR__ . '/../datos/ActividadModel.php';

$modelo = new ActividadModel();

// Si el usuario envió el formulario para guardar una actividad
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'crear') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $nivel_id = $_POST['nivel_id'];

    $resultado = $modelo->registrarActividad($nombre, $descripcion, $nivel_id);

    if ($resultado) {
        header("Location: ../vistas/gestionar_actividades.php?exito=1");
        exit();
    } else {
        header("Location: ../vistas/gestionar_actividades.php?error=1");
        exit();
    }
}
?>