<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../datos/ProgresoModel.php';

requireRole(2);

// Verificamos si los datos vienen de un formulario por el método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Capturamos los datos enviados desde la vista
    $estudiante_id = filter_input(INPUT_POST, 'estudiante_id', FILTER_VALIDATE_INT);
    $actividad_id = filter_input(INPUT_POST, 'actividad_id', FILTER_VALIDATE_INT);
    $fecha = date('Y-m-d'); // Generamos la fecha actual automáticamente
    $puntaje = filter_input(INPUT_POST, 'puntaje', FILTER_VALIDATE_INT);
    $estado = $_POST['estado'];

    // Instanciamos el modelo y llamamos a la función
    $modelo = new ProgresoModel();
    $registroExitoso = $estudiante_id && $actividad_id && $puntaje !== false
        ? $modelo->registrarProgreso($estudiante_id, $actividad_id, $fecha, $puntaje, $estado)
        : false;

    if ($registroExitoso) {
        // Redirigir o mostrar mensaje de éxito
        echo "¡Progreso guardado correctamente!";
    } else {
        echo "Hubo un error al guardar el progreso.";
    }
}
?>