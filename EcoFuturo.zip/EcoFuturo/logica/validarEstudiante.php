<?php
// Validar campos del ecoformulario de reciclaje

function validarDatosEstudiante($id_estudiante, $material, $cantidad) {
    $errores = [];

    if (empty($id_estudiante) || !filter_var($id_estudiante, FILTER_VALIDATE_INT)) {
        $errores[] = "Debe seleccionar un estudiante válido.";
    }

    if (empty($material)) {
        $errores[] = "Debe seleccionar un tipo de material reciclado.";
    }

    if (empty($cantidad) || !filter_var($cantidad, FILTER_VALIDATE_FLOAT) || $cantidad <= 0) {
        $errores[] = "La cantidad debe ser un número mayor a cero.";
    }

    return $errores;
}

// Restricción de acceso exclusivo para Administradores
function verificarAccesoAdministrador() {
    if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'administrador') {
        header("Location: " . BASE_URL . "vistas/formularioEstudiante.php?error=acceso_denegado");
        exit();
    }
}

?>