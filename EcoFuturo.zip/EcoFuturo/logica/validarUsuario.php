<?php

function validarDatosUsuario($nombre, $correo, $password, $id_rol): array
{
    $errores = [];
    if ($nombre === '') $errores[] = 'nombre';
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) $errores[] = 'correo';
    if (strlen($password) < 8) $errores[] = 'password';
    if ((int)$id_rol < 1) $errores[] = 'rol';
    return $errores;
}
?>