CREATE DATABASE IF NOT EXISTS `proyecto_reciclaje`
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;
USE `proyecto_reciclaje`;
SET SQL_NOTES = 0;

-- Esquema unificado: incluye los cambios de puntaje, nivel e imagen.
-- Este script recrea las tablas y elimina los datos existentes al ejecutarse.
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `progreso`, `ecoformularios`, `contenidos`, `actividad`, `temas_ambientales`, `profesores`, `estudiantes`, `usuarios`, `roles`, `nivel`;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_rol` varchar(50) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `nombre_rol` (`nombre_rol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion`) VALUES
(1, 'Administrador', 'Acceso total al sistema'),
(2, 'Profesor', 'Crea temas, actividades y evalúa entregas'),
(3, 'Estudiante', 'Desarrolla actividades y consulta calificaciones');

CREATE TABLE `nivel` (
  `nivel_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_nivel` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `puntos_minimos` int(11) DEFAULT 0,
  PRIMARY KEY (`nivel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `nivel` (`nivel_id`, `nombre_nivel`, `descripcion`, `puntos_minimos`) VALUES
(1, 'Principiante', 'Nivel básico para introducción a conceptos ambientales', 10),
(2, 'Intermedio', 'Nivel medio para actividades de aplicación y maquetas', 30),
(3, 'Avanzado', 'Nivel alto para proyectos interactivos y de investigación', 50);

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `usuario_login` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `cuenta_activa` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `correo` (`correo`),
  UNIQUE KEY `usuario_login` (`usuario_login`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `fk_usuarios_roles` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `correo`, `usuario_login`, `password`, `id_rol`, `cuenta_activa`, `fecha_registro`) VALUES
(1, 'Administrador Principal', 'admin@ecofuturo.com', 'admin', '$2y$10$tM84efvcqlq9hsx6YtwjOO6OlZt7zu2L79VgQ.OhckOpPXtl9sNpC', 1, 1, '2026-09-06 19:05:56');

CREATE TABLE `estudiantes` (
  `id_estudiante` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `documento` varchar(20) NOT NULL,
  `grado` varchar(20) NOT NULL,
  `curso` varchar(10) NOT NULL,
  PRIMARY KEY (`id_estudiante`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  UNIQUE KEY `documento` (`documento`),
  CONSTRAINT `fk_estudiantes_usuarios` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE `profesores` (
  `id_profesor` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `documento` varchar(20) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `curso` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_profesor`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  UNIQUE KEY `documento` (`documento`),
  CONSTRAINT `fk_profesores_usuarios` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE `temas_ambientales` (
  `id_tema` int(11) NOT NULL AUTO_INCREMENT,
  `id_profesor` int(11) NOT NULL,
  `titulo_tema` varchar(120) NOT NULL,
  `categoria` enum('Charla','Taller','Proyecto','Actividad Interactiva') NOT NULL,
  `descripcion` text NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_tema`),
  KEY `id_profesor` (`id_profesor`),
  CONSTRAINT `fk_temas_usuarios` FOREIGN KEY (`id_profesor`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE `actividad` (
  `actividad_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `nivel_id` int(11) DEFAULT NULL,
  `id_tema` int(11) DEFAULT NULL,
  `titulo_actividad` varchar(150) DEFAULT NULL,
  `instrucciones` text DEFAULT NULL,
  `puntaje_maximo` int(11) DEFAULT 50,
  `fecha_limite` datetime DEFAULT NULL,
  `permite_retraso` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_publicacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`actividad_id`),
  KEY `nivel_id` (`nivel_id`),
  KEY `id_tema` (`id_tema`),
  CONSTRAINT `fk_actividad_nivel` FOREIGN KEY (`nivel_id`) REFERENCES `nivel` (`nivel_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_actividad_tema` FOREIGN KEY (`id_tema`) REFERENCES `temas_ambientales` (`id_tema`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE `ecoformularios` (
  `id_ecoformulario` int(11) NOT NULL AUTO_INCREMENT,
  `actividad_id` int(11) NOT NULL,
  `id_estudiante` int(11) NOT NULL,
  `respuesta_texto` text DEFAULT NULL,
  `archivo_respuesta` varchar(255) DEFAULT NULL,
  `nombre_archivo_original` varchar(255) DEFAULT NULL,
  `puntos_obtenidos` int(11) DEFAULT 0,
  `observaciones_profesor` text DEFAULT NULL,
  `fecha_entrega` datetime DEFAULT current_timestamp(),
  `entrega_con_retraso` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_ecoformulario`),
  UNIQUE KEY `uq_ecoformulario_actividad_estudiante` (`actividad_id`,`id_estudiante`),
  KEY `actividad_id` (`actividad_id`),
  KEY `id_estudiante` (`id_estudiante`),
  CONSTRAINT `fk_eco_actividad` FOREIGN KEY (`actividad_id`) REFERENCES `actividad` (`actividad_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eco_estudiantes` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id_estudiante`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE `progreso` (
  `progreso_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(11) NOT NULL,
  `actividad_id` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `puntaje` int(11) DEFAULT 0,
  `estado` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`progreso_id`),
  KEY `id_estudiante` (`id_estudiante`),
  KEY `actividad_id` (`actividad_id`),
  CONSTRAINT `fk_progreso_actividad` FOREIGN KEY (`actividad_id`) REFERENCES `actividad` (`actividad_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_progreso_estudiante` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id_estudiante`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


SET SQL_NOTES = 1;