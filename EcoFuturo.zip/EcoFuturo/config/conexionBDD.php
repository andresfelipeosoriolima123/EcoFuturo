<?php
// config/conexionBDD.php

$host = "localhost";
$dbname = "proyecto_reciclaje"; // Cambia si el nombre de tu base de datos es distinto
$username = "root";
$password = "";

try {
    // Variable procedural/global por si algún archivo la requiere directamente
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Alias por compatibilidad
    $pdo = $conn;
    $db = $conn;

} catch (PDOException $e) {
    die("Error de conexión a la base de datos: " . $e->getMessage());
}

// Clase estática para los archivos DAO que usan ConexionBDD::getInstancia()
if (!class_exists('ConexionBDD')) {
    class ConexionBDD {
        public static function getInstancia() {
            global $conn;
            return $conn;
        }
    }
}
?>