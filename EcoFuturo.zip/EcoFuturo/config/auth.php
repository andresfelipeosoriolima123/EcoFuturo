<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (in_array((int) ($_SESSION['id_rol'] ?? 0), [2, 3], true)) {
    require_once __DIR__ . '/conexionBDD.php';
}

function requireRole(int $role): void
{
    if ((int)($_SESSION['id_rol'] ?? 0) !== $role) {
        http_response_code(403);
        exit('Acceso no autorizado.');
    }

    if ($role === 2 || $role === 3) {
        $conexion = ConexionBDD::getInstancia();
        if (!$conexion instanceof PDO) {
            http_response_code(503);
            exit('No se pudo establecer conexión con la base de datos. Intenta nuevamente más tarde.');
        }
        $stmt = $conexion->prepare(
            'SELECT cuenta_activa FROM usuarios WHERE id_usuario = ? AND id_rol = ?'
        );
        $stmt->execute([(int) ($_SESSION['id_usuario'] ?? 0), $role]);

        if ((int) $stmt->fetchColumn() !== 1) {
            $_SESSION = [];
            session_destroy();
            http_response_code(403);
            exit('La cuenta está inactiva. Contacta al administrador.');
        }
    }
}
