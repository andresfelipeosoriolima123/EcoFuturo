<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

require_once __DIR__ . '/../../config/conexionBDD.php';
$conexion = ConexionBDD::getInstancia();

$actividad_id = filter_input(INPUT_GET, 'actividad_id', FILTER_VALIDATE_INT);
if (!$actividad_id) {
    header('Location: gestionar_actividades.php');
    exit();
}

$actividad = null;
try {
    $stmt = $conexion->prepare("SELECT a.actividad_id, a.titulo_actividad, a.instrucciones, a.puntaje_maximo, a.fecha_limite, a.permite_retraso
                                FROM actividad a
                                INNER JOIN temas_ambientales t ON t.id_tema = a.id_tema
                                WHERE a.actividad_id = ? AND t.id_profesor = ?");
    $stmt->execute([$actividad_id, $_SESSION['id_usuario']]);
    $actividad = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $actividad = null;
}

if (!$actividad) {
    header('Location: gestionar_actividades.php?error=actividad_no_encontrada');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Actividad</title>
    <link rel="stylesheet" href="../../css/profesor/crearactividad.css">
    <style>
        body { margin: 0; background: #f4f6f9; font-family: 'Segoe UI', Arial, sans-serif; }
        .container { max-width: 760px; margin: 40px auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.08); }
        .sub-title { margin-bottom: 20px; }
        .form-group { margin-bottom: 18px; }
        .btn-submit { background: var(--color-secondary); color: white; }
        .btn-secondary { display: inline-block; margin-top: 15px; color: #1b5e20; text-decoration: none; font-size: 13px; font-weight: 600; }
    </style>
</head>
<body>
    <div class="container">
        <h2>✏️ Editar Actividad</h2>
        <p class="sub-title">Actualiza la información de la actividad asignada.</p>

        <form action="../../procesos/profesor/guardarEdicionActividad.php" method="POST">
            <input type="hidden" name="actividad_id" value="<?= (int) $actividad['actividad_id'] ?>">

            <div class="form-group">
                <label for="titulo_actividad">Título de la Actividad:</label>
                <input type="text" id="titulo_actividad" name="titulo_actividad" maxlength="150" value="<?= htmlspecialchars($actividad['titulo_actividad']) ?>" required>
            </div>

            <div class="form-group">
                <label for="puntaje_maximo">Puntaje Máximo (Puntos):</label>
                <input type="number" id="puntaje_maximo" name="puntaje_maximo" min="1" max="50" value="<?= (int) $actividad['puntaje_maximo'] ?>" required>
                <small class="field-help">El puntaje máximo permitido es de 50 puntos.</small>
            </div>

            <div class="form-group">
                <label for="fecha_vencimiento">Fecha y hora de vencimiento (opcional):</label>
                <input type="datetime-local" id="fecha_vencimiento" name="fecha_vencimiento" min="<?= date('Y-m-d') ?>T00:00"
                       value="<?= $actividad['fecha_limite'] ? htmlspecialchars(date('Y-m-d\TH:i', strtotime($actividad['fecha_limite']))) : '' ?>">
            </div>

            <div class="form-group">
                <label for="permite_retraso">
                    <input type="checkbox" id="permite_retraso" name="permite_retraso" value="1" style="width:auto; margin-right:8px;" <?= !empty($actividad['permite_retraso']) ? 'checked' : '' ?>>
                    Permitir entregas después de la fecha límite
                </label>
            </div>

            <div class="form-group">
                <label for="instrucciones">Instrucciones y Requisitos:</label>
                <textarea id="instrucciones" name="instrucciones" rows="5" required><?= htmlspecialchars($actividad['instrucciones']) ?></textarea>
            </div>

            <button type="submit" class="btn-submit">Guardar Cambios</button>
        </form>

        <div style="text-align: center; margin-top: 15px;">
            <a href="gestionar_actividades.php" class="btn-secondary">← Regresar</a>
        </div>
    </div>
</body>
</html>
