<?php
// vistas/profesor/crearActividad.php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

// Inclusión directa de tu archivo de conexión real
include_once(__DIR__ . '/../../config/conexionBDD.php');

// Mapeo seguro de la variable de conexión
$conexion = null;
if (isset($conn)) {
    $conexion = $conn;
} elseif (isset($pdo)) {
    $conexion = $pdo;
} elseif (isset($db)) {
    $conexion = $db;
}

$temas = [];
$errorBD = "";

if ($conexion) {
    try {
        $stmt = $conexion->prepare("SELECT id_tema, titulo_tema
                                    FROM temas_ambientales
                                    WHERE id_profesor = ?
                                    ORDER BY id_tema DESC");
        $stmt->execute([(int) $_SESSION['id_usuario']]);
        $temas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $errorBD = "Error al consultar los temas: " . $e->getMessage();
    }
} else {
    $errorBD = "No se pudo detectar la variable de conexión en conexionBDD.php.";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Asignar Nueva Actividad</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/profesor/crearactividad.css">
</head>
<body>

<header class="top-navbar">
    <a href="indexProfesor.php" class="logo" aria-label="Volver al panel del profesor" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
        <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
        <span>EcoFuturo - Panel Docente</span>
    </a>
    <a href="indexProfesor.php" class="btn-regresar">← Regresar al panel</a>
</header>

<div class="container">
    <h2>📝 Publicar Nueva Actividad</h2>
    <p class="sub-title">Asigna talleres, tareas y entregables evaluables a tus estudiantes.</p>

    <?php if (!empty($errorBD)): ?>
        <div class="alert-error"><?php echo htmlspecialchars($errorBD); ?></div>
    <?php endif; ?>

    <form action="../../procesos/profesor/guardarActividad.php" method="POST">
        
        <div class="form-group">
            <label for="id_tema">Tema Asociado:</label>
            <select id="id_tema" name="id_tema" required>
                <option value="" disabled selected>-- Seleccione un Tema --</option>
                <?php if (!empty($temas)): ?>
                    <?php foreach ($temas as $t): ?>
                        <option value="<?php echo $t['id_tema']; ?>"><?php echo htmlspecialchars($t['titulo_tema']); ?></option>
                    <?php endforeach; ?>
                <?php else: ?>
                    <option value="" disabled>No hay temas registrados</option>
                <?php endif; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="titulo_actividad">Título de la Actividad:</label>
            <input type="text" id="titulo_actividad" name="titulo_actividad" maxlength="150" placeholder="Ej. Taller Práctico de Separación de Residuos" required>
        </div>

        <div class="form-group">
            <label for="puntaje_maximo">Puntaje Máximo (Puntos):</label>
            <input type="number" id="puntaje_maximo" name="puntaje_maximo" placeholder="Ej. 50" min="1" max="50" required>
            <small class="field-help">El puntaje máximo permitido es de 50 puntos.</small>
        </div>

        <div class="form-group">
            <label for="fecha_vencimiento">Fecha y hora de vencimiento (opcional):</label>
            <input type="datetime-local" id="fecha_vencimiento" name="fecha_vencimiento" min="<?= date('Y-m-d') ?>T00:00">
        </div>

        <div class="form-group">
            <label for="permite_retraso">
                <input type="checkbox" id="permite_retraso" name="permite_retraso" value="1" style="width:auto; margin-right:8px;">
                Permitir entregas después de la fecha límite
            </label>
        </div>

        <div class="form-group">
            <label for="instrucciones">Instrucciones y Requisitos:</label>
            <textarea id="instrucciones" name="instrucciones" rows="5" placeholder="Detalla los pasos que deben seguir los estudiantes para realizar la entrega..." required></textarea>
        </div>

        <button type="submit" class="btn-submit">Asignar Actividad 🚀</button>
    </form>
</div>

</body>
</html>