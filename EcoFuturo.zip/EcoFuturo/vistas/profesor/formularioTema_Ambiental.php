<?php
// vistas/profesor/formularioTema_Ambiental.php
require_once __DIR__ . '/../../config/conexionBDD.php';
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Lecciones Ambientales</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/profesor/TemaAmbiental.css">
</head>
<body>

<div class="container">
    <h2>📚 Planificación de Lección Ambiental</h2>
    <p class="sub-title">Registra los temas ecológicos y pedagógicos que se impartirán en el aula.</p>

    <form action="../../procesos/profesor/guardar_tema.php" method="POST">
        
        <!-- Título del Tema -->
        <div class="form-group">
            <label for="titulo_tema">Título del Tema a Enseñar:</label>
            <input type="text" id="titulo_tema" name="titulo_tema" placeholder="Ej. Clasificación de residuos según el código de colores" required>
        </div>

        <!-- Categoría del Tema -->
        <div class="form-group">
            <label for="categoria">Categoría del Tema:</label>
            <select id="categoria" name="categoria" required>
                <option value="">-- Seleccione una categoría --</option>
                <option value="Charla">Charla</option>
                <option value="Taller">Taller</option>
                <option value="Proyecto">Proyecto</option>
                <option value="Actividad Interactiva">Actividad Interactiva</option>
            </select>
        </div>

        <!-- Descripción / Objetivo -->
        <div class="form-group">
            <label for="descripcion">Descripción / Objetivo de la Lección:</label>
            <textarea id="descripcion" name="descripcion" rows="4" placeholder="Describe los contenidos, metodologías y objetivos..." required></textarea>
        </div>

        <!-- Botón de Envío -->
        <button type="submit" class="btn-submit">Registrar Tema para Clase 📝</button>

    </form>
</div>

</body>
</html>
