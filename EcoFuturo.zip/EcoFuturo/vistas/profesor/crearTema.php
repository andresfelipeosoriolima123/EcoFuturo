<?php 
// vistas/profesor/crearTema.php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Crear Tema Ambiental</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/profesor/creartema.css">
</head>
<body>

    <!-- Barra superior fija con el logo como regreso y botón de salida -->
    <header class="top-navbar">
        <a href="indexProfesor.php" class="logo" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
            <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
            <span>EcoFuturo - Panel Docente</span>
        </a>
        <a href="indexProfesor.php" class="btn-salir">Salir</a>
    </header>

    <!-- Contenedor principal del formulario -->
    <div class="card-container profesor">
        <div class="logo-header">
            <div class="brand">
                <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:38px; height:38px; object-fit:contain; border-radius:50%; background:#fff;">
                <h1>EcoFuturo</h1>
            </div>
            <p>Registro de Nuevo Tema Ambiental</p>
        </div>

        <form action="../../procesos/profesor/guardar_tema.php" method="POST">
            <!-- Título del Tema -->
            <div class="form-group">
                <label for="titulo_tema">Título del Tema</label>
                <input type="text" id="titulo_tema" name="titulo_tema" placeholder="Ej: Gestión de Residuos Sólidos" required>
            </div>

            <!-- Categoría Principal -->
            <div class="form-group">
                <label for="categoria">Categoría Principal</label>
                <select id="categoria" name="categoria" required>
                    <option value="" disabled selected>Selecciona una categoría</option>
                    <option value="Charla">Charla</option>
                    <option value="Taller">Taller</option>
                    <option value="Proyecto">Proyecto</option>
                    <option value="Actividad Interactiva">Actividad Interactiva</option>
                </select>
            </div>

            <!-- Descripción Breve -->
            <div class="form-group">
                <label for="descripcion">Descripción Breve</label>
                <textarea id="descripcion" name="descripcion" rows="3" placeholder="Describe un breve resumen o propósito pedagógico..." required></textarea>
            </div>

            <button type="submit" class="btn-submit">Guardar Tema</button>
        </form>

        <div style="text-align: center; margin-top: 15px;">
            <a href="indexProfesor.php" style="color: #0077b6; text-decoration: none; font-size: 13px; font-weight: 600;">← Regresar</a>
        </div>
    </div>

</body>
</html>