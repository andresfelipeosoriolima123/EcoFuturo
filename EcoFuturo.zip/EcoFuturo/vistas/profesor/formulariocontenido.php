<?php
// vistas/profesor/formulariocontenido.php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Crear Tema Ambiental</title>
    <!-- Enlace al archivo CSS externo actualizado -->
    <link rel="stylesheet" href="../../css/profesor/formulariocontenido.css">
</head>
<body>
    <div class="card-container profesor">
        <div class="logo-header">
            <div class="brand">
                <span class="brand-icon">🌱</span>
                <h1>EcoFuturo</h1>
            </div>
            <p>Registro de Nuevo contenido</p>
        </div>

        <form action="../../procesos/profesor/guardar_tema.php" method="POST">
            <div class="form-group">
                <label for="titulo_tema">Título del Contenido</label>
                <input type="text" id="titulo_tema" name="titulo_tema" placeholder="Ej: Gestión de Residuos Sólidos" required>
            </div>

            <div class="form-group">
                <label for="categoria">Categoría Principal</label>
                <select id="categoria" name="categoria" required>
                    <option value="" disabled selected>Selecciona una categoría</option>
                    <option value="Charla">Charla</option>
                    <option value="Taller">Taller</option>
                    <option value="Proyecto">Proyecto</option>
                    <option value="Actividad Interactiva">Actividad Interactiva</option>
                </select>
            </div>

            <div class="form-group">
                <label for="descripcion">Descripción del Tema</label>
                <textarea id="descripcion" name="descripcion" rows="4" placeholder="Describe el propósito pedagógico de este tema..." required></textarea>
            </div>

            <button type="submit" class="btn-submit">Guardar Tema</button>
        </form>

        <div style="text-align: center; margin-top: 15px;">
            <a href="indexProfesor.php" style="color: #0077b6; text-decoration: none; font-size: 13px; font-weight: 600;">← Regresar</a>
        </div>
    </div>
</body>
</html>