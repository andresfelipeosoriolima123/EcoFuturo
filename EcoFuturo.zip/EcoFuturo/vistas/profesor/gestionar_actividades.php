<?php
// vistas/profesor/gestionar_actividades.php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

$conexion = null;
$rutasConexion = [
    __DIR__ . '/../../config/conexionBDD.php',
    __DIR__ . '/../../config/conexion.php',
    __DIR__ . '/../../modelo/conexionBDD.php',
    __DIR__ . '/../../conexionBDD.php'
];

foreach ($rutasConexion as $ruta) {
    if (file_exists($ruta)) {
        include_once $ruta;
        if (!isset($conexion)) {
            if (isset($conn)) $conexion = $conn;
            elseif (isset($db)) $conexion = $db;
            elseif (isset($pdo)) $conexion = $pdo;
        }
        break;
    }
}

$mensaje = '';
if (isset($_GET['msj']) && $_GET['msj'] === 'actividad_actualizada') {
    $mensaje = '<div class="alerta exito">Actividad actualizada con éxito.</div>';
} elseif (isset($_GET['error']) && $_GET['error'] === 'fecha_invalida') {
    $mensaje = '<div class="alerta error">La fecha de vencimiento no es válida.</div>';
}

// Procesar eliminación si se solicita
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar']) && $conexion) {
    $idEliminar = intval($_POST['eliminar']);
    try {
        $stmtDel = $conexion->prepare("DELETE a FROM actividad a INNER JOIN temas_ambientales t ON t.id_tema = a.id_tema WHERE a.actividad_id = ? AND t.id_profesor = ?");
        $stmtDel->execute([$idEliminar, $_SESSION['id_usuario']]);
        $mensaje = '<div class="alerta exito">Actividad eliminada con éxito.</div>';
    } catch (Exception $e) {
        $mensaje = '<div class="alerta error">No se pudo eliminar la actividad porque ya contiene entregas asociadas.</div>';
    }
}

$actividades = [];
if ($conexion) {
    try {
        $query = "SELECT a.actividad_id, a.titulo_actividad, a.puntaje_maximo, a.fecha_publicacion, a.fecha_limite, t.titulo_tema
                  FROM actividad a
                  INNER JOIN temas_ambientales t ON a.id_tema = t.id_tema
                  WHERE t.id_profesor = ?
                  ORDER BY a.fecha_publicacion DESC";
        $stmtActividades = $conexion->prepare($query);
        $stmtActividades->execute([$_SESSION['id_usuario']]);
        $actividades = $stmtActividades->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $mensaje = '<div class="alerta error">No se pudieron cargar las actividades.</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EcoFuturo - Gestionar Actividades</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/profesor/gestionaractividades.css">
</head>
<body>

<header>
    <a href="indexProfesor.php" class="logo" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
        <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
        <span>EcoFuturo</span>
    </a>
    <a href="indexProfesor.php" class="btn-volver">← Regresar</a>
</header>

<div class="container">
    <h1>📋 Gestión de Actividades Asignadas</h1>
    <?= $mensaje ?>

    <?php if (empty($actividades)): ?>
        <p style="text-align: center; background: white; padding: 20px; border-radius: 8px;">No hay actividades registradas.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Tema</th>
                    <th>Título Actividad</th>
                    <th>Puntaje</th>
                    <th>Fecha Publicación</th>
                    <th>Vencimiento</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($actividades as $act): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($act['titulo_tema']) ?></strong></td>
                        <td><?= htmlspecialchars($act['titulo_actividad']) ?></td>
                        <td><?= $act['puntaje_maximo'] ?> pts</td>
                        <td><?= date("d/m/Y", strtotime($act['fecha_publicacion'])) ?></td>
                        <td><?= $act['fecha_limite'] ? date("d/m/Y H:i", strtotime($act['fecha_limite'])) : 'Sin fecha límite' ?></td>
                        <td>
                            <div class="acciones-tabla">
                                <a href="editarActividad.php?actividad_id=<?= (int) $act['actividad_id'] ?>" class="btn-edit">Editar</a>
                                <form method="POST" onsubmit="return confirm('¿Está seguro de eliminar esta actividad?')">
                                    <input type="hidden" name="eliminar" value="<?= $act['actividad_id'] ?>">
                                    <button type="submit" class="btn-eliminar">Eliminar</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

</body>
</html>