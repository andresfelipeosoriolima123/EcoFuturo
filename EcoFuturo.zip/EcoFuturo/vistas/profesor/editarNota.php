<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

require_once __DIR__ . '/../../config/conexionBDD.php';
$conexion = ConexionBDD::getInstancia();

$id_ecoformulario = filter_input(INPUT_GET, 'id_ecoformulario', FILTER_VALIDATE_INT);
if (!$id_ecoformulario) {
    header('Location: evaluarEntregas.php');
    exit();
}

$entrega = null;
try {
    $stmt = $conexion->prepare("SELECT ef.id_ecoformulario, ef.puntos_obtenidos, ef.observaciones_profesor,
                                c.titulo_actividad, c.puntaje_maximo,
                                u.nombre AS nombre_estudiante
                                FROM ecoformularios ef
                                INNER JOIN actividad c ON c.actividad_id = ef.actividad_id
                                INNER JOIN temas_ambientales t ON t.id_tema = c.id_tema
                                INNER JOIN estudiantes e ON e.id_estudiante = ef.id_estudiante
                                INNER JOIN usuarios u ON u.id_usuario = e.id_usuario
                                WHERE ef.id_ecoformulario = ? AND t.id_profesor = ?");
    $stmt->execute([$id_ecoformulario, $_SESSION['id_usuario']]);
    $entrega = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $entrega = null;
}

if (!$entrega) {
    header('Location: evaluarEntregas.php?error=entrega_no_encontrada');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Nota</title>
    <link rel="stylesheet" href="../../css/profesor/evaluarentregas.css">
    <style>
        body { margin: 0; background: #f4f6f9; font-family: 'Segoe UI', Arial, sans-serif; }
        .container { max-width: 760px; margin: 40px auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.08); }
        .field { margin-bottom: 18px; }
        .form-line { display: flex; gap: 15px; flex-wrap: wrap; }
        .btn-calificar { margin-top: 10px; }
        .btn-secondary { display: inline-block; margin-top: 10px; color: #1b5e20; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="container">
        <h1>✏️ Editar Nota</h1>

        <div class="respuesta">
            <strong>Estudiante:</strong> <?= htmlspecialchars($entrega['nombre_estudiante']) ?><br>
            <strong>Actividad:</strong> <?= htmlspecialchars($entrega['titulo_actividad']) ?>
        </div>

        <form action="../../procesos/profesor/guardarEdicionNota.php" method="POST" class="form-calificar" style="display:block;">
            <input type="hidden" name="id_ecoformulario" value="<?= (int) $entrega['id_ecoformulario'] ?>">

            <div class="field" style="max-width: 180px;">
                <label>Puntaje obtenido / calificación (Máx <?= (int) $entrega['puntaje_maximo'] ?>):</label>
                <input type="number" name="puntos_obtenidos" min="0" max="<?= (int) $entrega['puntaje_maximo'] ?>" value="<?= (int) ($entrega['puntos_obtenidos'] ?? 0) ?>" required>
            </div>

            <div class="field">
                <label>Observaciones / Retroalimentación:</label>
                <input type="text" name="observaciones_profesor" value="<?= htmlspecialchars($entrega['observaciones_profesor'] ?? '') ?>" placeholder="Ej. Excelente trabajo con el material reciclable.">
            </div>

            <button type="submit" class="btn-calificar">Guardar Cambios</button>
        </form>

        <div style="text-align: center; margin-top: 15px;">
            <a href="evaluarEntregas.php" class="btn-secondary">← Regresar</a>
        </div>
    </div>
</body>
</html>
