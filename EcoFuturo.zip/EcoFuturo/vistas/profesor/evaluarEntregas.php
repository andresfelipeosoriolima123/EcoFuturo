<?php
// vistas/profesor/evaluarEntregas.php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

$conexion = null;
$rutasConexion = [
    __DIR__ . '/../../config/conexionBDD.php',
    __DIR__ . '/../../config/conexion.php',
    __DIR__ . '/../../modelo/conexionBDD.php',
    __DIR__ . '/../../conexionBDD.php'
];

foreach ($rutasConexion as $ruta) {
    if (file_exists($ruta)) {
        include_once $ruta;
        if (!isset($conexion)) {
            if (isset($conn)) $conexion = $conn;
            elseif (isset($db)) $conexion = $db;
            elseif (isset($pdo)) $conexion = $pdo;
        }
        break;
    }
}

$mensaje = '';
if (isset($_GET['msj']) && $_GET['msj'] === 'nota_guardada') {
    $mensaje = '<div class="alerta exito">Nota actualizada con éxito.</div>';
}

// Obtener los niveles exactos desde la base de datos (Principiante, Intermedio, Avanzado)
$nivelesBD = [];
if ($conexion) {
    try {
        $stmtNiveles = $conexion->query("SELECT nivel_id, nombre_nivel, puntos_minimos FROM nivel ORDER BY nivel_id ASC");
        $nivelesBD = $stmtNiveles->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $nivelesBD = [];
    }
}

$entregas = [];
if ($conexion) {
    $query = "SELECT 
                ef.id_ecoformulario,
                ef.respuesta_texto,
                ef.archivo_respuesta,
                ef.nombre_archivo_original,
                ef.fecha_entrega,
                ef.entrega_con_retraso,
                ef.puntos_obtenidos,
                ef.observaciones_profesor,
                c.titulo_actividad,
                c.puntaje_maximo,
                u.nombre AS nombre_estudiante,
                e.documento AS documento_estudiante
              FROM ecoformularios ef
              INNER JOIN actividad c ON ef.actividad_id = c.actividad_id
              INNER JOIN temas_ambientales t ON t.id_tema = c.id_tema
              INNER JOIN estudiantes e ON ef.id_estudiante = e.id_estudiante
              INNER JOIN usuarios u ON e.id_usuario = u.id_usuario
              WHERE t.id_profesor = ?
              ORDER BY ef.fecha_entrega DESC";
    $stmtEntregas = $conexion->prepare($query);
    $stmtEntregas->execute([$_SESSION['id_usuario']]);
    $entregas = $stmtEntregas->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EcoFuturo - Evaluar Entregas</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/profesor/evaluarentregas.css?v=2">
    <script>
        function actualizarNotaPorNivel(selectElement, inputPuntosId, maxPuntaje) {
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            const puntosMinimos = parseInt(selectedOption.getAttribute('data-puntos')) || 0;
            const inputPuntos = document.getElementById(inputPuntosId);
            
            if (selectElement.value !== "") {
                inputPuntos.value = Math.min(puntosMinimos, maxPuntaje);
            }
        }
    </script>
</head>
<body>

<header>
    <a href="indexProfesor.php" class="logo" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
        <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
        <span>EcoFuturo</span>
    </a>
    <a href="indexProfesor.php" class="btn-volver">← Regresar</a>
</header>

<div class="container">
    <h1>✅ Entregas de Estudiantes</h1>
    <?= $mensaje ?>

    <?php if (empty($entregas)): ?>
        <p style="text-align: center; background: white; padding: 20px; border-radius: 8px;">No hay entregas pendientes por evaluar.</p>
    <?php else: ?>
        <?php foreach ($entregas as $index => $ent): ?>
            <?php $inputIdPuntos = "puntos_" . $index; ?>
            <div class="card-entrega">
                <div class="card-header">
                    <div>
                        <div class="estudiante">👤 <?= htmlspecialchars($ent['nombre_estudiante']) ?></div>
                        <small style="color: #666;">Documento: <strong><?= htmlspecialchars($ent['documento_estudiante']) ?></strong></small><br>
                        <small style="color: #666;">Actividad: <strong><?= htmlspecialchars($ent['titulo_actividad']) ?></strong></small>
                    </div>
                    <div style="text-align: right;">
                        <span style="font-size: 12px; color: #666;">Enviado: <?= date("d/m/Y H:i:s", strtotime($ent['fecha_entrega'])) ?></span><br>
                        <strong style="font-size: 13px; color: <?= (int) $ent['entrega_con_retraso'] === 1 ? '#c62828' : '#0d5c99' ?>;">
                            <?= (int) $ent['entrega_con_retraso'] === 1 ? 'Entregada con retraso' : 'Entregada a tiempo' ?>
                        </strong>
                    </div>
                </div>

                <div class="respuesta">
                    <strong>Respuesta del Alumno:</strong><br>
                    <?= nl2br(htmlspecialchars($ent['respuesta_texto'])) ?>
                    <?php if (!empty($ent['archivo_respuesta'])): ?>
                        <div style="margin-top: 10px;">
                            <a href="../../uploads/<?= rawurlencode(basename($ent['archivo_respuesta'])) ?>" target="_blank" rel="noopener" style="color: #1e77c7; font-weight: bold; text-decoration: underline;">📎 <?= htmlspecialchars($ent['nombre_archivo_original'] ?: basename($ent['archivo_respuesta'])) ?></a>
                        </div>
                    <?php endif; ?>
                </div>

                <form action="../../procesos/profesor/evaluarEntrega.php" method="POST" class="form-calificar">
                    <input type="hidden" name="id_ecoformulario" value="<?= $ent['id_ecoformulario'] ?>">
                    
                    <div class="field" style="max-width: 200px;">
                        <label>Nivel de la Actividad:</label>
                        <select name="nivel_actividad" onchange="actualizarNotaPorNivel(this, '<?= $inputIdPuntos ?>', <?= $ent['puntaje_maximo'] ?>)">
                            <option value="">-- Seleccionar --</option>
                            <?php if (!empty($nivelesBD)): ?>
                                <?php foreach ($nivelesBD as $nivel): ?>
                                    <option value="<?= $nivel['nivel_id'] ?>" data-puntos="<?= $nivel['puntos_minimos'] ?>">
                                        <?= htmlspecialchars($nivel['nombre_nivel']) ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="field" style="max-width: 140px;">
                        <label>Puntaje obtenido / calificación (Máx <?= $ent['puntaje_maximo'] ?>):</label>
                        <input type="number" id="<?= $inputIdPuntos ?>" name="puntos_obtenidos" min="0" max="<?= $ent['puntaje_maximo'] ?>" value="<?= $ent['puntos_obtenidos'] ?? 0 ?>" required>
                    </div>
                    
                    <div class="field">
                        <label>Observaciones / Retroalimentación:</label>
                        <input type="text" name="observaciones_profesor" value="<?= htmlspecialchars($ent['observaciones_profesor'] ?? '') ?>" placeholder="Ej. Excelente trabajo con el material reciclable.">
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                        <button type="submit" name="calificar" class="btn-calificar">Guardar Nota</button>
                        <a href="editarNota.php?id_ecoformulario=<?= (int) $ent['id_ecoformulario'] ?>" class="btn-edit-note">Editar</a>
                    </div>
                </form>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

</body>
</html>