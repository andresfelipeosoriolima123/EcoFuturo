<?php
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar Progreso</title>
    <link rel="stylesheet" href="../../css/profesor/registrarprogreso.css">
</head>
<body>

    <h2>Registrar Avance de Actividad</h2>
    
    <!-- El formulario envía los datos al controlador mediante POST -->
    <form action="../../logica/ProgresoController.php" method="POST">
        <label for="estudiante_id">ID del Estudiante:</label>
        <input type="number" name="estudiante_id" required>
        <br><br>

        <label for="actividad_id">ID de la Actividad:</label>
        <input type="number" name="actividad_id" required>
        <br><br>

        <label for="puntaje">Puntaje Obtenido:</label>
        <input type="number" name="puntaje" required>
        <br><br>

        <label for="estado">Estado de la actividad:</label>
        <select name="estado" required>
            <option value="Completado">Completado</option>
            <option value="En proceso">En proceso</option>
            <option value="Pendiente">Pendiente</option>
        </select>
        <br><br>

        <button type="submit">Guardar Progreso</button>
    </form>

</body>
</html>
