<?php
// vistas/profesor/indexProfesor.php - Panel Principal del Profesor
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

// Conexión a base de datos subiendo dos niveles (../../)
$conexion = null;
$rutasConexion = [
    __DIR__ . '/../../config/conexionBDD.php',
    __DIR__ . '/../../config/conexion.php',
    __DIR__ . '/../../modelo/conexionBDD.php',
    __DIR__ . '/../../conexionBDD.php'
];

foreach ($rutasConexion as $ruta) {
    if (file_exists($ruta)) {
        include_once $ruta;
        if (!isset($conexion)) {
            if (isset($conn)) $conexion = $conn;
            elseif (isset($db)) $conexion = $db;
            elseif (isset($pdo)) $conexion = $pdo;
        }
        break;
    }
}

$nombreProfesor = $_SESSION['nombre'] ?? 'Profesor';
$idUsuario = $_SESSION['id_usuario'] ?? $_SESSION['id'] ?? 0;

$totalTemas = 0;
$totalActividades = 0;
$totalEntregas = 0;
$dashboardError = '';
$mensajeExito = '';

if (($_GET['msj'] ?? '') === 'tema_guardado') {
    $mensajeExito = 'Tema registrado correctamente.';
} elseif (($_GET['msj'] ?? '') === 'actividad_guardada') {
    $mensajeExito = 'Actividad registrada correctamente.';
}

if ($conexion) {
    try {
        $stmt1 = $conexion->prepare("SELECT COUNT(*) FROM temas_ambientales WHERE id_profesor = ?");
        $stmt1->execute([(int) $idUsuario]);
        $totalTemas = $stmt1->fetchColumn() ?: 0;

        $stmt2 = $conexion->prepare("SELECT COUNT(*) FROM actividad c
                                     INNER JOIN temas_ambientales t ON t.id_tema = c.id_tema
                                     WHERE t.id_profesor = ?");
        $stmt2->execute([(int) $idUsuario]);
        $totalActividades = $stmt2->fetchColumn() ?: 0;

        $stmt3 = $conexion->prepare("SELECT COUNT(*) FROM ecoformularios ef
                                     INNER JOIN actividad c ON c.actividad_id = ef.actividad_id
                                     INNER JOIN temas_ambientales t ON t.id_tema = c.id_tema
                                     WHERE t.id_profesor = ?");
        $stmt3->execute([(int) $idUsuario]);
        $totalEntregas = $stmt3->fetchColumn() ?: 0;
    } catch (Throwable $e) {
        $dashboardError = 'No se pudieron cargar las estadísticas del profesor.';
    }
} else {
    $dashboardError = 'No se pudo conectar con la base de datos.';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Panel Profesor</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/profesor/indexprofesor.css?v=2">
</head>
<body>

<header>
    <div class="logo" style="display:flex; align-items:center; gap:10px; color:#fff;">
        <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:38px; height:38px; object-fit:contain; border-radius:50%; background:#fff;">
        <img src="../../img/logo-colegio.png" alt="Escudo del colegio" style="width:40px; height:40px; object-fit:cover; border-radius:50%; background:#fff;">
        <span>EcoFuturo - Docentes</span>
    </div>
    <div>
        <span style="margin-right: 15px;">Prof. <?= htmlspecialchars($nombreProfesor) ?></span>
        <a href="../../procesos/cerrarSesion.php" class="btn-salir">Cerrar Sesión</a>
    </div>
</header>

<div class="container">
    <div class="welcome">
        <h2>Bienvenido, Profesor/a <?= htmlspecialchars($nombreProfesor) ?> 👋</h2>
        <p>Desde aquí puede gestionar sus contenidos pedagógicos, asignar actividades y calificar entregas de los estudiantes.</p>
    </div>
    <?php if ($dashboardError !== ''): ?>
        <p class="alert-error"><?= htmlspecialchars($dashboardError, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>
    <?php if ($mensajeExito !== ''): ?>
        <p class="alerta-exito" role="status"><?= htmlspecialchars($mensajeExito, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>

    <div class="stats-grid">
        <div class="stat-card">
            <div>Temas Publicados</div>
            <div class="stat-number"><?= $totalTemas ?></div>
        </div>
        <div class="stat-card">
            <div>Actividades Creadas</div>
            <div class="stat-number"><?= $totalActividades ?></div>
        </div>
        <div class="stat-card">
            <div>Entregas Recibidas</div>
            <div class="stat-number"><?= $totalEntregas ?></div>
        </div>
    </div>

    <div class="actions-grid">
        <div class="action-card">
            <h3>📂 Crear Tema</h3>
            <p>Publica un nuevo tema o unidad ambiental para tus alumnos.</p>
            <a href="crearTema.php" class="btn-action">+ Nuevo Tema</a>
        </div>
        <div class="action-card">
            <h3>📝 Crear Actividad</h3>
            <p>Diseña guías, tareas o formularios para evaluar el aprendizaje.</p>
            <a href="crearActividad.php" class="btn-action">+ Nueva Actividad</a>
        </div>
        <div class="action-card">
            <h3>📋 Gestionar Actividades</h3>
            <p>Modifica, actualiza o revisa las actividades activas del curso.</p>
            <a href="gestionar_actividades.php" class="btn-action">Ver Lista</a>
        </div>
        <div class="action-card">
            <h3>✅ Evaluar Entregas</h3>
            <p>Revisa las respuestas de los estudiantes y asigna puntajes.</p>
            <a href="evaluarEntregas.php" class="btn-action">Calificar</a>
        </div>
    </div>
</div>

</body>
</html>