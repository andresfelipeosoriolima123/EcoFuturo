<?php 
// vistas/estudiante/formularioEstudianteInfo.php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Información del Estudiante</title>
    <!-- Única hoja de estilo externa -->
    <link rel="stylesheet" href="../../css/autenticacion/registroestudiante.css?v=20261031">
</head>
<body>

    <!-- Barra superior con el logo redondo y botón de salida -->
    <header class="top-navbar">
        <div class="logo">
            <a href="../../index.php" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
                <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
                <span>EcoFuturo</span>
            </a>
            <img src="../../img/logo-colegio.png" alt="Escudo del colegio" style="width:42px; height:42px; object-fit:cover; border-radius:50%; background:#fff; margin-left:12px;">
        </div>
        <a href="../../index.php" class="btn-salir">Salir</a>
    </header>

    <div class="card-container">
        <div class="logo-header">
            <div class="brand">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#1e5e27" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.4 19 2c1 2 2 4.1 2 9 0 4.97-4.03 9-9 9z"/>
                    <path d="M11 20v-5a4 4 0 0 1 4-4h5"/>
                </svg>
                <h1>EcoFuturo</h1>
            </div>
            <p>Regístrate y forma parte del cambio ambiental</p>
        </div>

        <?php if (isset($_GET['error'])): ?>
            <div class="alert-error">
                <?php 
                    switch($_GET['error']) {
                        case 'campos_vacios':
                            echo 'Por favor, completa todos los campos obligatorios.';
                            break;
                        case 'formato_invalido':
                            echo 'Revisa los datos: el grado debe escribirse con palabras, el nombre con letras y el documento/curso con números.';
                            break;
                        case 'correo_invalido':
                            echo 'El formato del correo electrónico no es válido.';
                            break;
                        case 'usuario_existente':
                            echo 'El correo electrónico o nombre de usuario ya se encuentran registrados.';
                            break;
                        default:
                            echo 'Ocurrió un error inesperado.';
                    }
                ?>
            </div>
        <?php endif; ?>

        <form action="../../procesos/autenticacion/guardarEstudianteInfo.php" method="POST">
            <!-- Datos Personales -->
            <div class="form-group">
                <label for="nombre">Nombre completo</label>
                <!-- pattern permite letras con acentos y espacios -->
                <input type="text" id="nombre" name="nombre" placeholder="Ej: Juan Pérez" pattern="[A-Za-zñÑáéíóúÁÉÍÓÚ\s]+" title="Solo se permiten letras y espacios" required>
            </div>

            <div class="form-group">
                <label for="documento">Documento de identidad</label>
                <!-- pattern permite solo números -->
                <input type="text" id="documento" name="documento" placeholder="Ej: 1012345678" pattern="[0-9]+" title="Solo se permiten números" required>
            </div>

            <div class="form-group">
                <label for="correo">Correo electrónico</label>
                <input type="email" id="correo" name="correo" placeholder="Ej: juan@correo.com" required>
            </div>

            <!-- Datos Académicos -->
            <div class="form-group">
                <label for="grado">Grado escolar</label>
                <input type="text" id="grado" name="grado" placeholder="Ej: Sexto" pattern="[\p{L}\s]+" title="Escribe el grado con palabras, sin números" required>
            </div>

            <div class="form-group">
                <label for="curso">Curso o grupo</label>
                <!-- pattern permite solo números -->
                <input type="text" id="curso" name="curso" placeholder="Ej: 1101" pattern="[0-9]+" title="Solo se permiten números" required>
            </div>

            <!-- Datos de Inicio de Sesión -->
            <div class="form-group">
                <label for="usuario_login">Nombre de usuario</label>
                <input type="text" id="usuario_login" name="usuario_login" placeholder="Ej: juanperez123" required>
            </div>

            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" placeholder="Crea una contraseña segura" required>
            </div>

            <div class="form-group-checkbox consentimiento">
                <input type="checkbox" id="acepto" name="acepto" value="1" required>
                <div class="consentimiento-texto">
                    <label for="acepto">Autorizo, o mi representante legal si soy menor de edad, el tratamiento de mis datos personales en EcoFuturo</label>
                    <button type="button" class="consentimiento-enlace" id="abrir-consentimiento" aria-haspopup="dialog" aria-controls="consentimiento-modal">¿Qué estoy autorizando?</button>
                </div>
            </div>

            <button type="submit" class="btn-submit">Registrarme</button>
        </form>
    </div>

    <dialog class="consentimiento-modal" id="consentimiento-modal" aria-labelledby="consentimiento-titulo" aria-describedby="consentimiento-descripcion">
        <div class="consentimiento-modal-contenido">
            <h2 id="consentimiento-titulo">Autorización para el tratamiento de datos personales</h2>
            <p id="consentimiento-descripcion">Al marcar la casilla y enviar este formulario, autorizas a EcoFuturo a tratar los datos personales que proporcionas —como nombre, documento, correo, grado y curso— para crear y gestionar tu cuenta, facilitar tu participación en la plataforma y sus actividades ambientales, y enviarte comunicaciones relacionadas.</p>
            <p>Esta autorización se solicita conforme a la <strong>Ley 1581 de 2012</strong> y su Decreto Reglamentario 1377 de 2013, compilado en el Decreto 1074 de 2015. Puedes solicitar consulta, actualización, rectificación o supresión de tus datos y revocar la autorización conforme a la ley.</p>
            <p>Si eres menor de edad, la autorización debe ser otorgada por tu padre, madre o representante legal, quien debe revisar esta información.</p>
            <form method="dialog">
                <button type="submit" class="consentimiento-cerrar">Entendido</button>
            </form>
        </div>
    </dialog>

    <script>
        document.getElementById('abrir-consentimiento').addEventListener('click', function () {
            document.getElementById('consentimiento-modal').showModal();
        });
    </script>
</body>
</html>