<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Registro Profesor</title>
    <!-- Única hoja de estilos externa permitida -->
    <link rel="stylesheet" href="../../css/autenticacion/registroprofesor.css?v=20261006">
</head>
<body>

    <!-- Barra superior con el logo redondo y botón de salida -->
    <header class="top-navbar">
        <div class="logo">
            <a href="../../index.php" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
                <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
                <span>EcoFuturo</span>
            </a>
            <img src="../../img/logo-colegio.png" alt="Escudo del colegio" style="width:42px; height:42px; object-fit:cover; border-radius:50%; background:#fff; margin-left:12px;">
        </div>
        <a href="../../index.php" class="btn-salir">Salir</a>
    </header>

    <div class="card-container profesor">
        <div class="logo-header">
            <div class="brand">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1e77c7" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M2 12h20"></path>
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                </svg>
                <h1>EcoFuturo</h1>
            </div>
            <p>Registro de profesores aliados para el aprendizaje ambiental</p>
        </div>

        <form action="../../procesos/autenticacion/guardarProfesor.php" method="POST">
            <!-- Datos Personales -->
            <div class="form-group">
                <label for="nombre">Nombre completo</label>
                <input type="text" id="nombre" name="nombre" placeholder="Ej: María López" pattern="[A-Za-zñÑáéíóúÁÉÍÓÚ\s]+" title="Solo se permiten letras y espacios" required>
            </div>

            <div class="form-group">
                <label for="documento">Documento de identidad</label>
                <input type="text" id="documento" name="documento" placeholder="Ej: 52123456" pattern="[0-9]+" title="Solo se permiten números" required>
            </div>

            <div class="form-group">
                <label for="correo">Correo electrónico</label>
                <input type="email" id="correo" name="correo" placeholder="Ej: maria@educacionbogota.edu.co" required>
            </div>

            <div class="form-group">
                <label for="telefono">Teléfono de contacto</label>
                <input type="tel" id="telefono" name="telefono" placeholder="Ej: 3001234567" pattern="[0-9]+" title="Solo se permiten números" required>
            </div>

            <div class="form-group">
                <label for="curso">Curso asignado</label>
                <input type="text" id="curso" name="curso" placeholder="Ej: 601" pattern="[0-9]+" title="Solo se permiten números" required>
            </div>

            <!-- Datos de Inicio de Sesión -->
            <div class="form-group">
                <label for="usuario_login">Nombre de usuario</label>
                <input type="text" id="usuario_login" name="usuario_login" placeholder="Ej: marialopez2026" required>
            </div>

            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" placeholder="Crea una contraseña segura" required>
            </div>

            <div class="form-group-checkbox">
                <input type="checkbox" id="acepto" name="acepto" value="1" required>
                <label for="acepto">Acepto participar como docente aliado de EcoFuturo</label>
            </div>

            <button type="submit" class="btn-submit">Registrarme</button>
        </form>
    </div>
</body>
</html>