<?php
session_start();

if (isset($_SESSION['id_rol'])) {
    if ($_SESSION['id_rol'] == 2) {
        header("Location: ../profesor/indexProfesor.php");
        exit();
    } else if ($_SESSION['id_rol'] == 3) {
        header("Location: ../estudiante/indexEstudiante.php");
        exit();
    }
}

$mostrarErrorCredenciales = ($_GET['error'] ?? '') === 'credenciales';
$tipoRegistro = $_GET['registro'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - EcoFuturo</title>
    <!-- Hoja de estilos externa para el login -->
    <link rel="stylesheet" href="../../css/autenticacion/login.css?v=4">
</head>
<body>

    <div class="login-card">
        <div class="login-header">
            <img class="login-logo" src="../../img/logo-eco.svg?v=20261025-2" alt="Logo de EcoFuturo">
            <h1>Acceso a EcoFuturo</h1>
            <p>Ingresa como profesor o estudiante</p>
        </div>

        <?php if ($mostrarErrorCredenciales): ?>
            <div class="alerta-login" role="alert">Usuario, contraseña o rol incorrectos.</div>
        <?php elseif ($tipoRegistro === 'estudiante'): ?>
            <div class="alerta-exito" role="status">Estudiante registrado con éxito. Ya puedes iniciar sesión.</div>
        <?php elseif ($tipoRegistro === 'profesor'): ?>
            <div class="alerta-exito" role="status">Profesor registrado con éxito. Ya puedes iniciar sesión.</div>
        <?php endif; ?>

        <form action="../../procesos/autenticacion/validarLogin.php" method="POST">
            <div class="form-group">
                <label for="usuario">Usuario o correo</label>
                <input type="text" id="usuario" name="usuario" required placeholder="Ej: juan147">
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required placeholder="••••••••">
            </div>
            
            <div class="form-group">
                <label for="rol">Tipo de usuario</label>
                <select id="rol" name="rol" required>
                    <option value="" disabled selected>-- Seleccionar --</option>
                    <option value="3">Estudiante</option>
                    <option value="2">Profesor</option>
                </select>
            </div>

            <button type="submit" class="btn-submit">Ingresar</button>
        </form>

        <a class="footer-link" href="../../index.php">Volver al inicio</a>
    </div>

</body>
</html>