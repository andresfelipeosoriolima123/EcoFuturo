<?php
// vistas/estudiante/verTemas.php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(3);

$conexion = null;
$rutasConexion = [
    __DIR__ . '/../../config/conexionBDD.php',
    __DIR__ . '/../../config/conexion.php',
    __DIR__ . '/../../modelo/conexionBDD.php',
    __DIR__ . '/../../conexionBDD.php'
];

foreach ($rutasConexion as $ruta) {
    if (file_exists($ruta)) {
        include_once $ruta;
        if (!isset($conexion)) {
            if (isset($conn)) $conexion = $conn;
            elseif (isset($db)) $conexion = $db;
            elseif (isset($pdo)) $conexion = $pdo;
        }
        break;
    }
}

$temas = [];
$errorTemas = '';
if ($conexion) {
    try {
        $query = "SELECT t.id_tema, t.titulo_tema, t.categoria, t.descripcion, t.fecha_creacion, u.nombre AS nombre_profesor
                  FROM temas_ambientales t
                  LEFT JOIN usuarios u ON t.id_profesor = u.id_usuario
                  ORDER BY t.fecha_creacion DESC";
        $stmt = $conexion->query($query);
        $temas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        $errorTemas = 'No se pudieron cargar los temas. Intenta nuevamente más tarde.';
    }
} else {
    $errorTemas = 'No se pudo conectar con la base de datos.';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EcoFuturo - Ver Temas</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/estudiante/vertemas.css">
</head>
<body>

<header>
    <a href="indexEstudiante.php" class="logo" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
        <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
        <span>EcoFuturo</span>
    </a>
    <a href="indexEstudiante.php" class="btn-volver">← Regresar</a>
</header>

<div class="container">
    <h1>🌍 Temas Ambientales</h1>
    <?php if ($errorTemas !== ''): ?>
        <p role="alert"><?= htmlspecialchars($errorTemas, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>
    <?php if (empty($temas)): ?>
        <p style="text-align: center; background: white; padding: 20px; border-radius: 8px;">No hay temas disponibles.</p>
    <?php else: ?>
        <div class="grid-temas">
            <?php foreach ($temas as $t): ?>
                <div class="card-tema">
                    <div>
                        <span class="categoria"><?= htmlspecialchars($t['categoria']) ?></span>
                        <h3 class="titulo"><?= htmlspecialchars($t['titulo_tema']) ?></h3>
                        <p class="descripcion"><?= nl2br(htmlspecialchars($t['descripcion'])) ?></p>
                    </div>
                    <a href="verContenido.php?id=<?= (int) $t['id_tema'] ?>" class="btn-ver-detalle">Ver Tema Completo</a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>