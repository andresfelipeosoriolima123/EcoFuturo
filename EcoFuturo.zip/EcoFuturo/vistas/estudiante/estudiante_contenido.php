<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(3);

if (!isset($_SESSION['id_usuario']) || $_SESSION['id_rol'] != 3) {
    header("Location: ../autenticacion/login.php");
    exit();
}

require_once __DIR__ . '/../../config/conexionBDD.php';

$conn = ConexionBDD::getInstancia();

$temas = [];
$error_sql = null;

try {
    $sql = "SELECT * FROM temas_ambientales ORDER BY id_tema DESC";
    $stmt = $conn->prepare($sql);

    $stmt->execute();
    $temas = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    $error_sql = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel del Estudiante - Contenidos</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/estudiante/estudiante_contenidos.css">
</head>
<body>

<nav class="navbar">
    <a href="indexEstudiante.php" class="navbar-brand" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
        <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
        <span>EcoFuturo</span>
    </a>
        <a href="indexEstudiante.php" class="btn-regresar">← Regresar</a>
    </div>
</nav>

<div class="container">
    <h2>Actividades y Contenidos Disponibles</h2>
    <p>Selecciona una actividad para ver su contenido completo:</p>

    <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">

    <?php if ($error_sql): ?>
        <div class="alerta-error">
            <strong>⚠️ Se detectó un problema:</strong><br>
            <?php echo htmlspecialchars($error_sql); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($temas)): ?>
        <?php foreach ($temas as $t): ?>
            <div class="card">
                <h3><?php echo htmlspecialchars($t['titulo_tema'] ?? 'Sin título'); ?></h3>
                <p><strong>Categoría:</strong> <?php echo htmlspecialchars($t['categoria'] ?? 'General'); ?></p>
                <p><?php echo htmlspecialchars($t['descripcion'] ?? ''); ?></p>
                <a href="verContenido.php?id=<?php echo (int) $t['id_tema']; ?>" class="btn-ver">Ver Contenido Completo</a>
            </div>
        <?php endforeach; ?>
    <?php elseif (!$error_sql): ?>
        <p>No hay actividades publicadas por el momento.</p>
    <?php endif; ?>
</div>

</body>
</html>