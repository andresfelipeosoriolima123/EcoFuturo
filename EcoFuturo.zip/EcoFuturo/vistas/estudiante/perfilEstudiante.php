<?php
// vistas/estudiante/perfilEstudiante.php
session_start();
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/conexionBDD.php';
requireRole(3);

$stmtEstudiante = $pdo->prepare('SELECT id_estudiante FROM estudiantes WHERE id_usuario = ?');
$stmtEstudiante->execute([$_SESSION['id_usuario']]);
$id_estudiante = $stmtEstudiante->fetchColumn();

if (!$id_estudiante) {
    exit('El perfil de estudiante no está configurado.');
}

// 1. Obtener la suma total de puntos obtenidos
$sqlPuntos = "SELECT COALESCE(SUM(puntos_obtenidos), 0) AS total_puntos 
              FROM ecoformularios 
              WHERE id_estudiante = :id";
$stmtPuntos = $pdo->prepare($sqlPuntos);
$stmtPuntos->execute(['id' => $id_estudiante]);
$totalPuntos = $stmtPuntos->fetchColumn();

// 2. Determinar el Nivel Actual y Puntos Necesarios para el Siguiente Nivel
if ($totalPuntos < 100) {
    $nivelActual = "Principiante";
    $puntosSiguiente = 100;
    $puntosFaltantes = $puntosSiguiente - $totalPuntos;
} elseif ($totalPuntos < 300) {
    $nivelActual = "Intermedio";
    $puntosSiguiente = 300;
    $puntosFaltantes = $puntosSiguiente - $totalPuntos;
} else {
    $nivelActual = "Avanzado";
    $puntosSiguiente = $totalPuntos; // Nivel máximo alcanzado
    $puntosFaltantes = 0;
}
?>

<!-- Bloque de Visualización para el Estudiante -->
<div class="card-nivel" style="background: #e8f5e9; padding: 20px; border-radius: 10px; border-left: 5px solid #2e7d32;">
    <h3>🏆 Tu Nivel Actual: <strong><?= $nivelActual ?></strong></h3>
    <p>Puntos acumulados: <strong><?= $totalPuntos ?> pts</strong></p>
    
    <?php if ($puntosFaltantes > 0): ?>
        <p>💡 Te faltan <strong><?= $puntosFaltantes ?> puntos</strong> para alcanzar el siguiente nivel.</p>
        <small>Realiza y entrega más actividades asignadas por tus profesores para subir de nivel.</small>
    <?php else: ?>
        <p>🎉 ¡Felicidades! Has alcanzado el nivel máximo (Avanzado).</p>
    <?php endif; ?>
</div>