<?php
// vistas/estudiante/verContenido.php
session_start(); // Iniciamos sesión para leer el rol del usuario

require_once __DIR__ . '/../../config/auth.php';
requireRole(3);
require_once __DIR__ . '/../../config/conexionBDD.php'; // Conexión ajustada a la subcarpeta
require_once __DIR__ . '/../../datos/TemaDAO.php'; // DAO ajustado a la subcarpeta

$id_tema = $_GET['id'] ?? null;

// Definimos la página de retorno según el rol (si es estudiante o profesor)
$url_regreso = (isset($_SESSION['id_rol']) && $_SESSION['id_rol'] == 3) ? 'estudiante_contenido.php' : '../profesor/indexProfesor.php';

if (!$id_tema) {
    header("Location: " . $url_regreso);
    exit();
}

$temaDAO = new TemaDAO();
$tema = $temaDAO->obtenerTemaPorId($id_tema);

if (!$tema) {
    echo "<div style='text-align:center; padding: 50px; font-family: sans-serif;'>
            <h2>El tema solicitado no existe.</h2>
            <a href='" . $url_regreso . "' style='color:#2e7d32;'>Volver</a>
          </div>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($tema['titulo_tema']); ?> - EcoFuturo</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/estudiante/vercontenido.css">
</head>
<body>

    <!-- Barra de navegación superior -->
    <nav class="navbar">
        <a href="<?= htmlspecialchars($url_regreso, ENT_QUOTES, 'UTF-8') ?>" class="navbar-brand" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
            <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
            <span>EcoFuturo</span>
        </a>
        <div class="navbar-user">
            <a href="<?= htmlspecialchars($url_regreso, ENT_QUOTES, 'UTF-8') ?>" class="btn-regresar">← Regresar</a>
        </div>
    </nav>

    <!-- Encabezado de la lección -->
    <header class="hero-header">
        <span class="badge-categoria"><?php echo htmlspecialchars($tema['categoria'] ?? 'General'); ?></span>
        <h1><?php echo htmlspecialchars($tema['titulo_tema']); ?></h1>
    </header>

    <!-- Contenido -->
    <main class="container">
        
        <div class="descripcion">
            <?php echo nl2br(htmlspecialchars($tema['descripcion'])); ?>
        </div>

        <div class="acciones">
            <?php if (isset($_SESSION['id_rol']) && $_SESSION['id_rol'] == 3): ?>
                <a href="estudiante_contenido.php" class="btn-volver">
                    ← Regresar
                </a>
            <?php else: ?>
                <a href="../profesor/indexProfesor.php" class="btn-volver">
                    ← Regresar
                </a>
            <?php endif; ?>
        </div>
    </main>

</body>
</html>