<?php
// vistas/estudiante/indexEstudiante.php - Panel Principal
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(3);

$conexion = null;
$rutasConexion = [
    __DIR__ . '/../../config/conexionBDD.php',
    __DIR__ . '/../../config/conexion.php',
    __DIR__ . '/../../modelo/conexionBDD.php',
    __DIR__ . '/../../conexionBDD.php'
];

foreach ($rutasConexion as $ruta) {
    if (file_exists($ruta)) {
        include_once $ruta;
        if (!isset($conexion)) {
            if (isset($conn)) $conexion = $conn;
            elseif (isset($db)) $conexion = $db;
            elseif (isset($pdo)) $conexion = $pdo;
        }
        break;
    }
}

$idUsuario = $_SESSION['id_usuario'] ?? $_SESSION['id'] ?? 0;
$idEstudiante = 0;
$temasDisponibles = 0;
$actividadesCompletadas = 0;
$actividadesPendientes = 0;
$misPuntos = 0;
$dashboardError = '';

if ($conexion) {
    try {
        $stmtEst = $conexion->prepare("SELECT id_estudiante FROM estudiantes WHERE id_usuario = ?");
        $stmtEst->execute([$idUsuario]);
        $idEstudiante = $stmtEst->fetchColumn() ?: 0;
        if (!$idEstudiante) {
            throw new RuntimeException('El perfil de estudiante no está configurado.');
        }

        $stmt1 = $conexion->query("SELECT COUNT(*) FROM temas_ambientales");
        $temasDisponibles = $stmt1->fetchColumn() ?: 0;

        $stmt2 = $conexion->prepare("SELECT COUNT(*) FROM ecoformularios WHERE id_estudiante = ?");
        $stmt2->execute([$idEstudiante]);
        $actividadesCompletadas = $stmt2->fetchColumn() ?: 0;

        $stmt3 = $conexion->prepare("SELECT COUNT(*) FROM actividad a
                                     WHERE a.id_tema IS NOT NULL
                                       AND NOT EXISTS (
                                           SELECT 1 FROM ecoformularios ef
                                           WHERE ef.actividad_id = a.actividad_id AND ef.id_estudiante = ?
                                       )");
        $stmt3->execute([$idEstudiante]);
        $actividadesPendientes = $stmt3->fetchColumn() ?: 0;

        $stmt4 = $conexion->prepare("SELECT COALESCE(SUM(puntos_obtenidos), 0) FROM ecoformularios WHERE id_estudiante = ?");
        $stmt4->execute([$idEstudiante]);
        $misPuntos = (int) ($stmt4->fetchColumn() ?: 0);
    } catch (Throwable $e) {
        $dashboardError = 'No se pudieron cargar los datos del estudiante.';
    }
} else {
    $dashboardError = 'No se pudo conectar con la base de datos.';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Panel Estudiante</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/estudiante/indexestudiante.css?v=20261006-2">
</head>
<body>

<header>
    <div class="logo" style="display:flex; align-items:center; gap:10px; color:#fff;">
        <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:38px; height:38px; object-fit:contain; border-radius:50%; background:#fff;">
        <img src="../../img/logo-colegio.png" alt="Escudo del colegio" style="width:40px; height:40px; object-fit:cover; border-radius:50%; background:#fff;">
        <span>EcoFuturo</span>
    </div>
    <div>
        <a href="../../procesos/estudiante/cerrarSesion.php" class="btn-salir">Cerrar Sesión</a>
    </div>
</header>

<div class="hero">
    <h1><img src="../../img/logo-eco.svg?v=20261025-2" alt="" class="hero-logo">Panel de Aprendizaje Ecológico</h1>
    <p>Aprende, realiza actividades y acumula puntos con EcoFuturo.</p>
</div>
<?php if ($dashboardError !== ''): ?>
    <p role="alert"><?= htmlspecialchars($dashboardError, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<div class="contenedor-kpis">
    <div class="card-kpi">
        <div>Temas Disponibles</div>
        <div class="valor-kpi"><?= $temasDisponibles ?></div>
    </div>
    <div class="card-kpi">
        <div>Actividades Entregadas</div>
        <div class="valor-kpi"><?= $actividadesCompletadas ?></div>
    </div>
    <div class="card-kpi">
        <div>Pendientes</div>
        <div class="valor-kpi"><?= $actividadesPendientes ?></div>
    </div>
    <div class="card-kpi">
        <div>Puntos Totales</div>
        <div class="valor-kpi"><?= $misPuntos ?> pts</div>
    </div>
</div>

<div class="seccion-acciones">
    <div class="card-accion">
        <h2>📚 Explora Temas</h2>
        <p>Consulta las lecciones de reciclaje y desarrollo sostenible.</p>
        <a href="estudiante_contenido.php" class="btn-accion">Ver Temas</a>
    </div>
    <div class="card-accion">
        <h2>📝 Mis Actividades</h2>
        <p>Revisa guías pendientes y realiza tus entregas.</p>
        <a href="actividadesEstudiante.php" class="btn-accion">Ir a Actividades</a>
    </div>
</div>

</body>
</html>