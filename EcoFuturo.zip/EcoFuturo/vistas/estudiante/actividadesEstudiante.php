<?php
// vistas/estudiante/actividadesEstudiante.php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(3);

$conexion = null;
$rutasConexion = [
    __DIR__ . '/../../config/conexionBDD.php',
    __DIR__ . '/../../config/conexion.php',
    __DIR__ . '/../../modelo/conexionBDD.php',
    __DIR__ . '/../../conexionBDD.php'
];

foreach ($rutasConexion as $ruta) {
    if (file_exists($ruta)) {
        include_once $ruta;
        if (!isset($conexion)) {
            if (isset($conn)) $conexion = $conn;
            elseif (isset($db)) $conexion = $db;
            elseif (isset($pdo)) $conexion = $pdo;
        }
        break;
    }
}

$idUsuario = (int) ($_SESSION['id_usuario'] ?? 0);
$mensaje = '';
$actividades = [];

if (isset($_SESSION['error_entrega'])) {
    $mensaje = '<div class="alerta error" role="alert">' . htmlspecialchars($_SESSION['error_entrega'], ENT_QUOTES, 'UTF-8') . '</div>';
    unset($_SESSION['error_entrega']);
} elseif (($_GET['msj'] ?? '') === 'entrega_guardada') {
    $mensaje = (int) ($_GET['retraso'] ?? 0) === 1
        ? '<div class="alerta exito" role="status">¡Entrega enviada con retraso! El profesor verá la fecha y hora de envío.</div>'
        : '<div class="alerta exito" role="status">¡Entrega enviada a tiempo! Puedes actualizarla mientras el plazo siga abierto.</div>';
}

if ($conexion) {
    try {
        $stmtEst = $conexion->prepare("SELECT id_estudiante FROM estudiantes WHERE id_usuario = ?");
        $stmtEst->execute([$idUsuario]);
        $idEstudiante = $stmtEst->fetchColumn();

        if (!$idEstudiante) {
            exit('El perfil de estudiante no está configurado.');
        }

    $queryActividades = "SELECT a.actividad_id, a.titulo_actividad, a.instrucciones, a.puntaje_maximo, a.fecha_limite,
                                a.permite_retraso,
                                (a.fecha_limite IS NOT NULL AND NOW() > a.fecha_limite) AS plazo_vencido,
                                t.titulo_tema,
                                ef.id_ecoformulario, ef.respuesta_texto, ef.archivo_respuesta, ef.nombre_archivo_original,
                                ef.fecha_entrega, ef.entrega_con_retraso,
                                ef.puntos_obtenidos, ef.observaciones_profesor
                        FROM actividad a
                        INNER JOIN temas_ambientales t ON a.id_tema = t.id_tema
                        LEFT JOIN ecoformularios ef ON a.actividad_id = ef.actividad_id AND ef.id_estudiante = ?
                        ORDER BY a.actividad_id DESC";
                        
        $stmtAct = $conexion->prepare($queryActividades);
        $stmtAct->execute([$idEstudiante]);
        $actividades = $stmtAct->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        $actividades = [];
        $mensaje = '<div class="alerta error">No se pudieron cargar las actividades en este momento.</div>';
    }
} else {
    $mensaje = '<div class="alerta error">No se pudo conectar con la base de datos. Intenta nuevamente más tarde.</div>';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EcoFuturo - Mis Actividades</title>
    <!-- Enlace al archivo CSS externo -->
    <link rel="stylesheet" href="../../css/estudiante/actividadesestudiante.css">
</head>
<body>

<header>
    <a href="indexEstudiante.php" class="logo" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
        <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
        <span>EcoFuturo</span>
    </a>
    <a href="indexEstudiante.php" class="btn-volver">← Regresar</a>
</header>

<div class="container">
    <h1>📝 Actividades Asignadas</h1>
    <?= $mensaje ?>

    <?php if (empty($actividades)): ?>
        <p style="text-align: center; background: white; padding: 20px; border-radius: 8px;">No hay actividades registradas.</p>
    <?php else: ?>
        <?php foreach ($actividades as $act): ?>
            <div class="card-actividad">
                <span class="badge-tema"><?= htmlspecialchars($act['titulo_tema']) ?></span>
                <h2><?= htmlspecialchars($act['titulo_actividad']) ?></h2>
                <p><?= nl2br(htmlspecialchars($act['instrucciones'])) ?></p>
                <small>Puntaje Máximo: <?= $act['puntaje_maximo'] ?> pts</small>
                <p><strong>Fecha de vencimiento:</strong>
                    <?= $act['fecha_limite'] ? date('d/m/Y H:i', strtotime($act['fecha_limite'])) : 'Sin fecha límite' ?>
                </p>
                <?php if ($act['fecha_limite']): ?>
                    <p><strong>Se aceptan entregas tardías:</strong> <?= (int) $act['permite_retraso'] === 1 ? 'Sí' : 'No' ?></p>
                <?php endif; ?>

                <?php if ($act['id_ecoformulario']): ?>
                    <div style="background: #f9f9f9; padding: 12px; margin-top: 15px; border-radius: 6px; border: 1px solid #e0e0e0;">
                        <strong>Entrega recibida ✅</strong>
                        <strong style="color: <?= (int) $act['entrega_con_retraso'] === 1 ? '#c62828' : '#0d5c99' ?>;">
                            <?= (int) $act['entrega_con_retraso'] === 1 ? 'Entregada con retraso' : 'Entregada a tiempo' ?>
                        </strong><br>
                        <strong>Fecha y hora de envío:</strong> <?= date('d/m/Y H:i:s', strtotime($act['fecha_entrega'])) ?><br>
                        <strong>Tu respuesta:</strong><br>
                        <?= nl2br(htmlspecialchars($act['respuesta_texto'] ?? '', ENT_QUOTES, 'UTF-8')) ?><br>
                        <?php if (!empty($act['archivo_respuesta'])): ?>
                            <a href="../../uploads/<?= rawurlencode(basename($act['archivo_respuesta'])) ?>" target="_blank" rel="noopener">
                                <?= htmlspecialchars($act['nombre_archivo_original'] ?: basename($act['archivo_respuesta']), ENT_QUOTES, 'UTF-8') ?>
                            </a><br>
                        <?php endif; ?>
                        Puntaje obtenido / calificación: <?= $act['puntos_obtenidos'] ?? 0 ?> / <?= $act['puntaje_maximo'] ?> pts<br>
                        <em><?= htmlspecialchars(trim((string) ($act['observaciones_profesor'] ?? '')) ?: 'Pendiente de calificación', ENT_QUOTES, 'UTF-8') ?></em>
                    </div>
                <?php endif; ?>
                <?php if (!(int) $act['plazo_vencido'] || (int) $act['permite_retraso'] === 1): ?>
                <form action="../../procesos/estudiante/guardarEntrega.php" method="POST" enctype="multipart/form-data" style="margin-top: 15px;">
                    <input type="hidden" name="actividad_id" value="<?= (int) $act['actividad_id'] ?>">
                    <textarea name="respuesta_texto" placeholder="Escribe tu respuesta..." required></textarea>
                    <input type="file" name="archivo_respuesta" accept=".pdf,.txt,.jpg,.jpeg,.png">
                    <?php if ((int) $act['plazo_vencido'] === 1): ?>
                        <p style="color:#c62828; margin:8px 0;">El plazo venció. Tu trabajo se marcará como entregado con retraso.</p>
                    <?php endif; ?>
                    <button type="submit" name="enviar_actividad" class="btn-enviar">
                        <?= $act['id_ecoformulario'] ? 'Actualizar Entrega' : 'Enviar Entrega' ?>
                    </button>
                </form>
                <?php else: ?>
                    <p role="status" style="color:#c62828; margin-top:15px;">El plazo venció y el profesor no acepta entregas con retraso.</p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

</body>
</html>