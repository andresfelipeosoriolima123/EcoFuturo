<?php
// vistas/admin/indexAdmin.php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(1);
require_once __DIR__ . '/../../datos/UsuarioDAO.php';

$usuarioDAO = new UsuarioDAO();
$estudiantes = $usuarioDAO->obtenerEstudiantes();
$profesores  = $usuarioDAO->obtenerProfesores();

$mensaje = '';
if (isset($_GET['exito']) && $_GET['exito'] === 'eliminado') {
    $mensaje = '<div class="alert-error" style="background:#c8e6c9; color:#2e7d32;">Usuario eliminado con éxito.</div>';
} elseif (isset($_GET['exito']) && $_GET['exito'] === 'editado') {
    $mensaje = '<div class="alert-error" style="background:#c8e6c9; color:#2e7d32;">Usuario actualizado con éxito.</div>';
} elseif (isset($_GET['exito']) && $_GET['exito'] === 'estado_actualizado') {
    $mensaje = '<div class="alert-error" style="background:#c8e6c9; color:#2e7d32;">Estado de cuenta actualizado.</div>';
} elseif (isset($_GET['error'])) {
    $mensaje = '<div class="alert-error">No se pudo completar la operación.</div>';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Panel Admin</title>
    <link rel="stylesheet" href="../../css/admin/indexAdmin.css">
</head>
<body>

<header>
    <div class="header-brand" style="display:flex; align-items:center; gap:10px; color:#fff;">
        <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:38px; height:38px; object-fit:contain; border-radius:50%; background:#fff;">
        <img src="../../img/logo-colegio.png" alt="Escudo del colegio" style="width:40px; height:40px; object-fit:cover; border-radius:50%; background:#fff;">
        <span>EcoFuturo - Administración</span>
    </div>
    <div class="header-user">
        <span class="user-label"><?= htmlspecialchars($_SESSION['nombre'] ?? 'Admin') ?></span>
        <!-- Se comunica con: procesos/autenticacion/cerrarSesion.php -->
        <a href="../../procesos/autenticacion/cerrarSesion.php" class="btn-logout">Cerrar Sesión</a>
    </div>
</header>

<div class="main-container">
    <h1 class="page-title">Panel de Administración</h1>
    <?= $mensaje ?>

    <!-- ===== ESTUDIANTES ===== -->
    <div class="card-panel">
        <div class="card-header">
            <span class="card-title">🎓 Estudiantes</span>
            <span class="count-badge"><?= count($estudiantes) ?></span>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Documento</th>
                        <th>Grado</th>
                        <th>Curso</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($estudiantes)): ?>
                        <tr><td colspan="7" class="empty-row">No hay estudiantes registrados.</td></tr>
                    <?php else: ?>
                        <?php foreach ($estudiantes as $e): ?>
                            <tr>
                                <td><?= htmlspecialchars($e['nombre']) ?></td>
                                <td><?= htmlspecialchars($e['correo']) ?></td>
                                <td><?= htmlspecialchars($e['documento']) ?></td>
                                <td><span class="badge-cat"><?= htmlspecialchars($e['grado']) ?></span></td>
                                <td><?= htmlspecialchars($e['curso']) ?></td>
                                <td><?= (int) $e['cuenta_activa'] === 1 ? 'Activo' : 'Inactivo' ?></td>
                                <td>
                                    <div class="actions-cell">
                                        <a href="editarUsuario.php?id_usuario=<?= (int) $e['id_usuario'] ?>" class="btn-edit">Editar</a>
                                        <form action="../../procesos/admin/cambiarEstadoUsuario.php" method="POST">
                                            <input type="hidden" name="id_usuario" value="<?= (int) $e['id_usuario'] ?>">
                                            <input type="hidden" name="cuenta_activa" value="<?= (int) $e['cuenta_activa'] === 1 ? 0 : 1 ?>">
                                            <button type="submit" class="<?= (int) $e['cuenta_activa'] === 1 ? 'btn-delete' : 'btn-activate' ?>">
                                                <?= (int) $e['cuenta_activa'] === 1 ? 'Desactivar' : 'Activar' ?>
                                            </button>
                                        </form>
                                        <form action="../../procesos/admin/eliminarUsuario.php" method="POST" onsubmit="return confirm('¿Eliminar este estudiante?')">
                                            <input type="hidden" name="id_usuario" value="<?= $e['id_usuario'] ?>">
                                            <button type="submit" class="btn-delete">Eliminar</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ===== PROFESORES ===== -->
    <div class="card-panel">
        <div class="card-header">
            <span class="card-title">🍎 Profesores</span>
            <span class="count-badge"><?= count($profesores) ?></span>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Documento</th>
                        <th>Teléfono</th>
                        <th>Curso Asignado</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($profesores)): ?>
                        <tr><td colspan="7" class="empty-row">No hay profesores registrados.</td></tr>
                    <?php else: ?>
                        <?php foreach ($profesores as $p): ?>
                            <tr>
                                <td><?= htmlspecialchars($p['nombre']) ?></td>
                                <td><?= htmlspecialchars($p['correo']) ?></td>
                                <td><?= htmlspecialchars($p['documento']) ?></td>
                                <td><?= htmlspecialchars($p['telefono']) ?></td>
                                <td><span class="badge-cat"><?= htmlspecialchars($p['curso']) ?></span></td>
                                <td><?= (int) $p['cuenta_activa'] === 1 ? 'Activo' : 'Inactivo' ?></td>
                                <td>
                                    <div class="actions-cell">
                                        <a href="editarUsuario.php?id_usuario=<?= (int) $p['id_usuario'] ?>" class="btn-edit">Editar</a>
                                        <form action="../../procesos/admin/cambiarEstadoUsuario.php" method="POST">
                                            <input type="hidden" name="id_usuario" value="<?= (int) $p['id_usuario'] ?>">
                                            <input type="hidden" name="cuenta_activa" value="<?= (int) $p['cuenta_activa'] === 1 ? 0 : 1 ?>">
                                            <button type="submit" class="<?= (int) $p['cuenta_activa'] === 1 ? 'btn-delete' : 'btn-activate' ?>">
                                                <?= (int) $p['cuenta_activa'] === 1 ? 'Desactivar' : 'Activar' ?>
                                            </button>
                                        </form>
                                        <form action="../../procesos/admin/eliminarUsuario.php" method="POST" onsubmit="return confirm('¿Eliminar este profesor?')">
                                            <input type="hidden" name="id_usuario" value="<?= $p['id_usuario'] ?>">
                                            <button type="submit" class="btn-delete">Eliminar</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<footer></footer>

</body>
</html>
