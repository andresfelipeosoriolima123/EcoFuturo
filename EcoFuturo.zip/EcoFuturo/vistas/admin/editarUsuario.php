<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(1);
require_once __DIR__ . '/../../datos/UsuarioDAO.php';

$id_usuario = filter_input(INPUT_GET, 'id_usuario', FILTER_VALIDATE_INT);
if (!$id_usuario) {
    header('Location: indexAdmin.php');
    exit();
}

$usuarioDAO = new UsuarioDAO();
$usuario = $usuarioDAO->obtenerUsuarioPorId($id_usuario);

if (!$usuario) {
    header('Location: indexAdmin.php?error=usuario_no_encontrado');
    exit();
}

if ($usuario['id_rol'] == 3) {
    $perfil = $usuarioDAO->obtenerEstudiantePorUsuario($id_usuario);
    $tipo = 'estudiante';
} elseif ($usuario['id_rol'] == 2) {
    $perfil = $usuarioDAO->obtenerProfesorPorUsuario($id_usuario);
    $tipo = 'profesor';
} else {
    header('Location: indexAdmin.php?error=rol_no_soportado');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f7f2;
            margin: 0;
            padding: 40px 20px;
            color: #1f2d1a;
        }
        .container {
            max-width: 700px;
            margin: 0 auto;
            background: #fff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
        }
        h1 {
            color: #1c5222;
            margin-bottom: 20px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }
        .field {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        label {
            font-weight: 600;
            color: #2d3748;
        }
        input {
            padding: 10px 12px;
            border: 1px solid #cbd5e0;
            border-radius: 8px;
            font-size: 14px;
        }
        .actions {
            margin-top: 25px;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }
        .btn-submit {
            background: #2e7d32;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 10px 18px;
            font-weight: 700;
            cursor: pointer;
        }
        .btn-cancel {
            background: #e2e8f0;
            color: #1f2933;
            text-decoration: none;
            border-radius: 8px;
            padding: 10px 18px;
            font-weight: 700;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Editar <?= htmlspecialchars($tipo === 'estudiante' ? 'Estudiante' : 'Profesor') ?></h1>

        <form action="../../procesos/admin/guardarEdicionUsuario.php" method="POST">
            <input type="hidden" name="id_usuario" value="<?= (int) $usuario['id_usuario'] ?>">

            <div class="form-grid">
                <div class="field">
                    <label for="nombre">Nombre</label>
                    <input id="nombre" name="nombre" type="text" value="<?= htmlspecialchars($usuario['nombre']) ?>" required>
                </div>

                <div class="field">
                    <label for="correo">Correo</label>
                    <input id="correo" name="correo" type="email" value="<?= htmlspecialchars($usuario['correo']) ?>" required>
                </div>

                <?php if ($tipo === 'estudiante'): ?>
                    <div class="field">
                        <label for="documento">Documento</label>
                        <input id="documento" name="documento" type="text" value="<?= htmlspecialchars($perfil['documento']) ?>" required>
                    </div>

                    <div class="field">
                        <label for="grado">Grado</label>
                        <input id="grado" name="grado" type="text" value="<?= htmlspecialchars($perfil['grado']) ?>" pattern="[\p{L}\s]+" title="Escribe el grado con palabras, sin números" required>
                    </div>

                    <div class="field">
                        <label for="curso">Curso</label>
                        <input id="curso" name="curso" type="text" value="<?= htmlspecialchars($perfil['curso']) ?>" required>
                    </div>
                <?php else: ?>
                    <div class="field">
                        <label for="documento">Documento</label>
                        <input id="documento" name="documento" type="text" value="<?= htmlspecialchars($perfil['documento']) ?>" required>
                    </div>

                    <div class="field">
                        <label for="telefono">Teléfono</label>
                        <input id="telefono" name="telefono" type="text" value="<?= htmlspecialchars($perfil['telefono']) ?>" required>
                    </div>

                    <div class="field">
                        <label for="curso">Curso</label>
                        <input id="curso" name="curso" type="text" value="<?= htmlspecialchars($perfil['curso']) ?>" pattern="[0-9]+" title="Solo se permiten números" required>
                    </div>
                <?php endif; ?>
            </div>

            <div class="actions">
                <button type="submit" class="btn-submit">Guardar cambios</button>
                <a href="indexAdmin.php" class="btn-cancel">Cancelar</a>
            </div>
        </form>
    </div>
</body>
</html>
