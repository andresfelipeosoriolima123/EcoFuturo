<?php
// vistas/admin/loginAdmin.php
session_start();

// Si ya hay sesión activa de admin, saltar directo al panel
if (isset($_SESSION['id_rol']) && (int)$_SESSION['id_rol'] === 1) {
    header("Location: indexAdmin.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Acceso Administrador</title>
    <link rel="stylesheet" href="../../css/admin/loginadmin.css">
</head>
<body>

    <header class="top-navbar">
        <div class="logo">
            <a href="../../index.php" style="display:flex; align-items:center; gap:10px; color:#fff; text-decoration:none;">
                <img src="../../img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:36px; height:36px; object-fit:contain; border-radius:50%; background:#fff;">
                <span>EcoFuturo</span>
            </a>
            <img src="../../img/logo-colegio.png" alt="Escudo del colegio" style="width:36px; height:36px; object-fit:cover; border-radius:50%; background:#fff; margin-left:10px;">
        </div>
        <a href="../../index.php" class="btn-salir">Salir</a>
    </header>

    <div class="container">
        <div class="header-logo">
            <h1>🛠️ Panel de Administración</h1>
            <p>Acceso exclusivo para administradores de EcoFuturo</p>
        </div>

        <?php if (isset($_GET['error'])): ?>
            <div class="form-group" style="background:#ffebee; color:#c62828; padding:10px; border-radius:6px; text-align:center; font-size:13px;">
                Correo o contraseña incorrectos.
            </div>
        <?php endif; ?>

        <!-- Se comunica con: procesos/admin/validarLoginAdmin.php -->
        <form action="../../procesos/admin/validarLoginAdmin.php" method="POST">
            <div class="form-group">
                <label for="correo">Usuario o correo</label>
                <input type="text" id="correo" name="correo" placeholder="admin o admin@ecofuturo.com" required>
            </div>

            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" placeholder="••••••••" required>
            </div>

            <button type="submit" class="btn-admin">Ingresar</button>
        </form>
    </div>

</body>
</html>
