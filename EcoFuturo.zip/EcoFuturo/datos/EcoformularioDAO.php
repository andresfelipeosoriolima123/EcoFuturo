<?php
require_once __DIR__ . '/../config/conexionBDD.php';

class EcoformularioDAO {
    private $db;

    public function __construct() {
        $this->db = ConexionBDD::getInstancia();
    }

    // Guardar entrega de reciclaje
    public function registrarEntrega($actividad_id, $id_estudiante, $respuesta_texto, $archivo_respuesta = null, $nombre_archivo_original = null) {
        try {
            $stmt = $this->db->prepare("INSERT INTO ecoformularios
                (actividad_id, id_estudiante, respuesta_texto, archivo_respuesta, nombre_archivo_original)
                VALUES (?, ?, ?, ?, ?)");
            return $stmt->execute([$actividad_id, $id_estudiante, $respuesta_texto, $archivo_respuesta, $nombre_archivo_original]);
        } catch (PDOException $e) {
            return false;
        }
    }

    // Obtener lista completa de entregas con información del estudiante
    public function obtenerTodasLasEntregas() {
        $query = "SELECT e.id_ecoformulario, u.nombre, est.documento, est.grado, e.respuesta_texto,
                         e.archivo_respuesta, e.nombre_archivo_original, e.fecha_entrega,
                         a.actividad_id, a.titulo_actividad
                  FROM ecoformularios e
                  INNER JOIN actividad a ON a.actividad_id = e.actividad_id
                  INNER JOIN estudiantes est ON e.id_estudiante = est.id_estudiante
                  INNER JOIN usuarios u ON est.id_usuario = u.id_usuario
                  ORDER BY e.fecha_entrega DESC";
        return $this->db->query($query)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener la lista de estudiantes con su grado para cargar en selects
    public function obtenerEstudiantesFormulario() {
        $query = "SELECT est.id_estudiante, u.nombre, est.grado 
                  FROM estudiantes est 
                  INNER JOIN usuarios u ON est.id_usuario = u.id_usuario";
        return $this->db->query($query)->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>