<?php
// datos/UsuarioDAO.php
require_once __DIR__ . '/../config/conexionBDD.php';

class UsuarioDAO {
    private $db;

    public function __construct() {
        $this->db = ConexionBDD::getInstancia();
    }

    // Insertar un nuevo usuario principal
    public function insertarUsuario($nombre, $correo, $usuario_login, $password, $id_rol) {
        try {
            $stmt = $this->db->prepare("INSERT INTO usuarios (nombre, correo, usuario_login, password, id_rol, cuenta_activa) VALUES (?, ?, ?, ?, ?, 1)");
            $stmt->execute([$nombre, $correo, $usuario_login, $password, $id_rol]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            return false;
        }
    }

    // Insertar perfil de Estudiante
    public function insertarEstudiante($id_usuario, $documento, $grado, $curso) {
        try {
            $stmt = $this->db->prepare("INSERT INTO estudiantes (id_usuario, documento, grado, curso) VALUES (?, ?, ?, ?)");
            return $stmt->execute([$id_usuario, $documento, $grado, $curso]);
        } catch (PDOException $e) {
            return false;
        }
    }

    // Insertar perfil de Profesor
    public function insertarProfesor($id_usuario, $documento, $telefono, $curso) {
        try {
            $stmt = $this->db->prepare("INSERT INTO profesores (id_usuario, documento, telefono, curso) VALUES (?, ?, ?, ?)");
            return $stmt->execute([$id_usuario, $documento, $telefono, $curso]);
        } catch (PDOException $e) {
            return false;
        }
    }

    public function registrarEstudianteCompleto($nombre, $correo, $usuario_login, $password, $documento, $grado, $curso) {
        $this->db->beginTransaction();
        try {
            $stmtUsuario = $this->db->prepare("INSERT INTO usuarios (nombre, correo, usuario_login, password, id_rol, cuenta_activa)
                                               VALUES (?, ?, ?, ?, 3, 1)");
            $stmtUsuario->execute([$nombre, $correo, $usuario_login, $password]);
            $id_usuario = $this->db->lastInsertId();

            $stmtEstudiante = $this->db->prepare("INSERT INTO estudiantes (id_usuario, documento, grado, curso)
                                                  VALUES (?, ?, ?, ?)");
            $stmtEstudiante->execute([$id_usuario, $documento, $grado, $curso]);
            $this->db->commit();
            return $id_usuario;
        } catch (PDOException $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return false;
        }
    }

    public function registrarProfesorCompleto($nombre, $correo, $usuario_login, $password, $documento, $telefono, $curso) {
        $this->db->beginTransaction();
        try {
            $stmtUsuario = $this->db->prepare("INSERT INTO usuarios (nombre, correo, usuario_login, password, id_rol, cuenta_activa)
                                               VALUES (?, ?, ?, ?, 2, 1)");
            $stmtUsuario->execute([$nombre, $correo, $usuario_login, $password]);
            $id_usuario = $this->db->lastInsertId();

            $stmtProfesor = $this->db->prepare("INSERT INTO profesores (id_usuario, documento, telefono, curso)
                                                VALUES (?, ?, ?, ?)");
            $stmtProfesor->execute([$id_usuario, $documento, $telefono, $curso]);
            $this->db->commit();
            return $id_usuario;
        } catch (PDOException $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return false;
        }
    }

    // Obtener usuario por credenciales
    public function buscarPorLoginORCorreo($user_input, $id_rol) {
        $stmt = $this->db->prepare("SELECT id_usuario, nombre, correo, usuario_login, password, id_rol, cuenta_activa
                                    FROM usuarios
                                    WHERE (usuario_login = ? OR correo = ?)
                                      AND id_rol = ?
                                      AND cuenta_activa = 1");
        $stmt->execute([$user_input, $user_input, $id_rol]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
    }

    public function buscarCuentaInactivaPorLoginORCorreo($user_input, $id_rol) {
        $stmt = $this->db->prepare("SELECT password
                                    FROM usuarios
                                    WHERE (usuario_login = ? OR correo = ?)
                                      AND id_rol = ?
                                      AND cuenta_activa = 0");
        $stmt->execute([$user_input, $user_input, $id_rol]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
    }

    public function obtenerUsuarioPorId($id_usuario) {
        $stmt = $this->db->prepare("SELECT id_usuario, nombre, correo, usuario_login, id_rol, cuenta_activa
                                    FROM usuarios
                                    WHERE id_usuario = ?");
        $stmt->execute([$id_usuario]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
    }

    public function obtenerEstudiantePorUsuario($id_usuario) {
        $stmt = $this->db->prepare("SELECT documento, grado, curso
                                    FROM estudiantes
                                    WHERE id_usuario = ?");
        $stmt->execute([$id_usuario]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
    }

    public function obtenerProfesorPorUsuario($id_usuario) {
        $stmt = $this->db->prepare("SELECT documento, telefono, curso
                                    FROM profesores
                                    WHERE id_usuario = ?");
        $stmt->execute([$id_usuario]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
    }

    public function actualizarEstudiante($id_usuario, $nombre, $correo, $documento, $grado, $curso) {
        try {
            $this->db->beginTransaction();

            $stmtUsuario = $this->db->prepare("UPDATE usuarios
                                              SET nombre = ?, correo = ?
                                              WHERE id_usuario = ?");
            $stmtUsuario->execute([$nombre, $correo, $id_usuario]);

            $stmtPerfil = $this->db->prepare("UPDATE estudiantes
                                             SET documento = ?, grado = ?, curso = ?
                                             WHERE id_usuario = ?");
            $stmtPerfil->execute([$documento, $grado, $curso, $id_usuario]);

            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return false;
        }
    }

    public function actualizarProfesor($id_usuario, $nombre, $correo, $documento, $telefono, $curso) {
        try {
            $this->db->beginTransaction();

            $stmtUsuario = $this->db->prepare("UPDATE usuarios
                                              SET nombre = ?, correo = ?
                                              WHERE id_usuario = ?");
            $stmtUsuario->execute([$nombre, $correo, $id_usuario]);

            $stmtPerfil = $this->db->prepare("UPDATE profesores
                                             SET documento = ?, telefono = ?, curso = ?
                                             WHERE id_usuario = ?");
            $stmtPerfil->execute([$documento, $telefono, $curso, $id_usuario]);

            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return false;
        }
    }

    public function obtenerEstudiantes() {
        $stmt = $this->db->query("SELECT u.id_usuario, u.nombre, u.correo, u.cuenta_activa, e.documento, e.grado, e.curso
                                  FROM usuarios u
                                  INNER JOIN estudiantes e ON e.id_usuario = u.id_usuario
                                  WHERE u.id_rol = 3
                                  ORDER BY u.nombre, u.id_usuario");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerProfesores() {
        $stmt = $this->db->query("SELECT u.id_usuario, u.nombre, u.correo, u.cuenta_activa, p.documento, p.telefono, p.curso
                                  FROM usuarios u
                                  INNER JOIN profesores p ON p.id_usuario = u.id_usuario
                                  WHERE u.id_rol = 2
                                  ORDER BY u.nombre, u.id_usuario");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function actualizarEstadoCuenta($id_usuario, $cuenta_activa) {
        $stmt = $this->db->prepare("UPDATE usuarios
                                    SET cuenta_activa = ?
                                    WHERE id_usuario = ? AND id_rol IN (2, 3)");
        $stmt->execute([(int) $cuenta_activa, $id_usuario]);
        return $stmt->rowCount() === 1;
    }

    public function eliminarUsuario($id_usuario) {
        $stmt = $this->db->prepare("DELETE FROM usuarios
                                    WHERE id_usuario = ?
                                      AND id_rol IN (2, 3)");
        $stmt->execute([$id_usuario]);
        return $stmt->rowCount() === 1;
    }

    // Obtener roles
    public function obtenerRoles() {
        try {
            $stmt = $this->db->query("SELECT * FROM roles");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}
?>