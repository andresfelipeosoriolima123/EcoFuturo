<?php
// datos/TemaDAO.php
require_once __DIR__ . '/../config/conexionBDD.php';

class TemaDAO {
    private $db;

    public function __construct() {
        $this->db = ConexionBDD::getInstancia();
    }

    // Obtener todos los temas ambientales creados
    public function obtenerTemas() {
        try {
            $query = "SELECT * FROM temas_ambientales ORDER BY id_tema DESC";
            $stmt = $this->db->query($query);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    // Obtener un tema específico por su ID
    public function obtenerTemaPorId($id_tema) {
        try {
            $sql = "SELECT * FROM temas_ambientales WHERE id_tema = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$id_tema]);
            $tema = $stmt->fetch(PDO::FETCH_ASSOC);
            return $tema ?: null;
        } catch (PDOException $e) {
            return null;
        }
    }

    // Insertar un nuevo tema ambiental (con depuración de errores)
    public function insertarTema($id_profesor, $titulo_tema, $categoria, $descripcion) {
        try {
            $sql = "INSERT INTO temas_ambientales (id_profesor, titulo_tema, categoria, descripcion) VALUES (?, ?, ?, ?)";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$id_profesor, $titulo_tema, $categoria, $descripcion]);
        } catch (PDOException $e) {
            // Lanzamos la excepción para ver el mensaje exacto de MySQL en pantalla
            throw new Exception("Error en BD (insertarTema): " . $e->getMessage());
        }
    }
}
?>