<?php
// Archivo: datos/ActividadModel.php
require_once __DIR__ . '/../config/conexionBDD.php';

class ActividadModel {
    private $conexion;

    public function __construct() {
        $this->conexion = ConexionBDD::getInstancia();
    }

    // Registrar una nueva actividad
    public function registrarActividad($nombre, $descripcion, $nivel_id) {
        $sql = "INSERT INTO ACTIVIDAD (nombre, descripcion, nivel_id) VALUES (?, ?, ?)";
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([$nombre, $descripcion, $nivel_id]);
    }

    // Obtener la lista de actividades unidas a su nivel
    public function obtenerActividades() {
        $sql = "SELECT a.actividad_id, COALESCE(a.titulo_actividad, a.nombre) AS nombre,
                       COALESCE(a.instrucciones, a.descripcion) AS descripcion, n.nombre_nivel
                FROM ACTIVIDAD a
                LEFT JOIN NIVEL n ON a.nivel_id = n.nivel_id
                ORDER BY a.actividad_id DESC";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener la lista de niveles para llenar los selects del formulario
    public function obtenerNiveles() {
        $sql = "SELECT * FROM NIVEL";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>