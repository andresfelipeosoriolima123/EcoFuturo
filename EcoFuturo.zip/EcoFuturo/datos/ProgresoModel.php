<?php
// Incluye tu archivo de conexión a la base de datos
require_once __DIR__ . '/../config/conexionBDD.php';

class ProgresoModel {
    private $conexion;

    public function __construct() {
        // Asumiendo que tu archivo conexion.php retorna un objeto PDO o MySQLi
        $this->conexion = ConexionBDD::getInstancia();
    }

    // Método para insertar un nuevo progreso
    public function registrarProgreso($estudiante_id, $actividad_id, $fecha, $puntaje, $estado) {
        // Usamos ? para preparar la consulta y evitar Inyección SQL
        $sql = "INSERT INTO progreso (id_estudiante, actividad_id, fecha, puntaje, estado) 
                VALUES (?, ?, ?, ?, ?)";
        
        $stmt = $this->conexion->prepare($sql);
        
        // Ejecutamos pasando los parámetros exactos
        if ($stmt->execute([$estudiante_id, $actividad_id, $fecha, $puntaje, $estado])) {
            return true;
        } else {
            return false;
        }
    }
}
?>