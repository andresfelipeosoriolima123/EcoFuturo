<?php
require_once __DIR__ . '/../config/conexionBDD.php';

class AuthDAO {
    private $db;

    public function __construct() {
        $this->db = ConexionBDD::getInstancia();
    }

    public function obtenerUsuarioPorCredenciales($user, $id_rol) {
        $sql = "SELECT id_usuario, nombre, correo, usuario_login, password, id_rol, cuenta_activa 
                FROM usuarios 
                WHERE (usuario_login = ? OR correo = ?) 
                  AND id_rol = ? 
                  AND cuenta_activa = 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$user, $user, $id_rol]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function obtenerIdProfesor($id_usuario) {
        $sql = "SELECT id_profesor FROM profesores WHERE id_usuario = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id_usuario]);
        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        return $res['id_profesor'] ?? null;
    }

    public function obtenerDatosEstudiante($id_usuario) {
        $sql = "SELECT id_estudiante, grado, curso FROM estudiantes WHERE id_usuario = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id_usuario]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
}
?>