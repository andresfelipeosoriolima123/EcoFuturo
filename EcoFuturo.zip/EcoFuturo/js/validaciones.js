document.addEventListener("DOMContentLoaded", function () {
    const formularios = document.querySelectorAll("form");

    formularios.forEach((form) => {
        form.addEventListener("submit", function (e) {
            let esValido = true;
            const campos = form.querySelectorAll("input[required], select[required]");

            campos.forEach((campo) => {
                // Elimina bordes de error previos
                campo.style.borderColor = "#a5d6a7";

                // Validar campos vacíos
                if (!campo.value.trim()) {
                    esValido = false;
                    campo.style.borderColor = "#d32f2f";
                }

                // Validaciones numéricas (cantidades)
                if (campo.type === "number" && parseFloat(campo.value) <= 0) {
                    esValido = false;
                    campo.style.borderColor = "#d32f2f";
                    alert("La cantidad debe ser un valor numérico mayor a 0.");
                }

                // Validaciones de correo
                if (campo.type === "email") {
                    const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!regexCorreo.test(campo.value.trim())) {
                        esValido = false;
                        campo.style.borderColor = "#d32f2f";
                        alert("Por favor, ingrese un correo electrónico válido.");
                    }
                }
            });

            if (!esValido) {
                e.preventDefault();
                alert("Por favor, complete todos los campos requeridos correctamente.");
            }
        });
    });
});