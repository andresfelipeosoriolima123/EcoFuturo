<?php
// index.php - Página principal de EcoFuturo / Proyecto Reciclaje
$mostrarErrorCredenciales = ($_GET['error'] ?? '') === 'credenciales';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoFuturo - Educación Ambiental</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
 
        body {
            background: #f1f8f0;
            color: #1b3a1e;
        }
 
        /* ===== BARRA DE NAVEGACIÓN ===== */
        header {
            background: #1b5e20;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 14px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            position: sticky;
            top: 0;
            z-index: 100;
        }
 
        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }
 
        .logo img {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            object-fit: cover;
            background: #a5d6a7;
        }
 
        .logo span {
            color: #ffffff;
            font-size: 22px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
 
        /* Menú desplegable de ingreso */
        .menu-ingreso {
            position: relative;
        }
 
        .btn-ingreso {
            background: #66bb6a;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: background 0.3s;
        }
 
        .btn-ingreso:hover {
            background: #4caf50;
        }
 
        .lista-desplegable {
            display: none;
            position: absolute;
            right: 0;
            top: 48px;
            background: #ffffff;
            min-width: 220px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0,0,0,0.25);
        }
 
        .lista-desplegable.activo {
            display: block;
        }
 
        .lista-desplegable a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 13px 18px;
            text-decoration: none;
            color: #1b5e20;
            font-size: 14px;
            font-weight: 600;
            border-bottom: 1px solid #e8f5e9;
            transition: background 0.2s;
        }
 
        .lista-desplegable a:last-child {
            border-bottom: none;
        }
 
        .lista-desplegable a:hover {
            background: #e8f5e9;
        }

        .alerta-login {
            margin: 16px auto 0;
            width: min(92%, 680px);
            padding: 12px 16px;
            border: 1px solid #f1aeb5;
            border-left: 5px solid #c62828;
            border-radius: 6px;
            background: #f8d7da;
            color: #842029;
            text-align: center;
            font-size: 15px;
            font-weight: 600;
        }
 
        /* ===== SECCIÓN HERO ===== */
        .hero {
            position: relative;
            background: linear-gradient(rgba(27,94,32,0.75), rgba(46,125,50,0.6)),
                        url('img/hero-bosque.jpg');
            background-size: cover;
            background-position: center;
            color: #ffffff;
            text-align: center;
            padding: 90px 20px;
        }
 
        .hero h1 {
            font-size: 40px;
            margin-bottom: 15px;
        }

        .hero-logo {
            width: 38px;
            height: 38px;
            object-fit: contain;
            vertical-align: middle;
            margin-right: 8px;
            border-radius: 50%;
            background: #a5d6a7;
        }
 
        .hero p {
            font-size: 18px;
            max-width: 650px;
            margin: 0 auto;
            color: #e8f5e9;
        }
 
        /* ===== SECCIONES GENERALES ===== */
        section {
            padding: 60px 8%;
        }
 
        .titulo-seccion {
            text-align: center;
            font-size: 30px;
            color: #2e7d32;
            margin-bottom: 40px;
            position: relative;
        }
 
        .titulo-seccion::after {
            content: "";
            display: block;
            width: 70px;
            height: 4px;
            background: #66bb6a;
            margin: 10px auto 0;
            border-radius: 5px;
        }
 
        /* Quiénes somos */
        .quienes-somos {
            display: flex;
            align-items: center;
            gap: 40px;
            flex-wrap: wrap;
            background: #ffffff;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
 
        .quienes-somos img {
            flex: 1 1 350px;
            width: 100%;
            max-width: 450px;
            border-radius: 15px;
            object-fit: cover;
            height: 300px;
        }
 
        .quienes-somos-texto {
            flex: 1 1 350px;
        }
 
        .quienes-somos-texto h3 {
            color: #388e3c;
            font-size: 24px;
            margin-bottom: 12px;
        }
 
        .quienes-somos-texto p {
            font-size: 15px;
            line-height: 1.7;
            color: #33502f;
        }
 
        /* Nuestro propósito */
        .proposito {
            background: #e8f5e9;
        }
 
        .tarjetas-proposito {
            display: flex;
            gap: 25px;
            flex-wrap: wrap;
            justify-content: center;
        }
 
        .tarjeta {
            background: #ffffff;
            border-radius: 15px;
            padding: 25px;
            width: 260px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border-top: 5px solid #4caf50;
            transition: transform 0.3s;
        }
 
        .tarjeta:hover {
            transform: translateY(-6px);
        }
 
        .tarjeta .icono {
            font-size: 40px;
            margin-bottom: 12px;
        }
 
        .tarjeta h4 {
            color: #2e7d32;
            margin-bottom: 8px;
            font-size: 17px;
        }
 
        .tarjeta p {
            font-size: 13.5px;
            color: #4a614a;
            line-height: 1.5;
        }
 
        /* Formas de aprendizaje */
        .aprendizaje-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 25px;
        }
 
        .aprendizaje-tarjeta {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            background: #ffffff;
        }
 
        .aprendizaje-tarjeta img {
            width: 100%;
            height: 170px;
            object-fit: cover;
        }
 
        .aprendizaje-info {
            padding: 18px;
            border-top: 4px solid #81c784;
        }
 
        .aprendizaje-info h4 {
            color: #1b5e20;
            margin-bottom: 8px;
            font-size: 16px;
        }
 
        .aprendizaje-info p {
            font-size: 13.5px;
            color: #4a614a;
            line-height: 1.5;
        }
 
        /* ===== FOOTER ===== */
        footer {
            background: #1b3a1e;
            color: #c8e6c9;
            text-align: center;
            padding: 25px;
            font-size: 13px;
        }
 
        @media (max-width: 600px) {
            .hero h1 { font-size: 28px; }
            .titulo-seccion { font-size: 24px; }
        }
    </style>
</head>
<body>
 
<!-- ===== ENCABEZADO ===== -->
<header>
    <div class="logo">
        <div style="display:flex; align-items:center; gap:10px; color:#fff;">
            <img src="img/logo-eco.svg?v=20261025-2" alt="Logo EcoFuturo" style="width:38px; height:38px; object-fit:contain; border-radius:50%; background:#fff;">
            <img src="img/logo-colegio.png" alt="Escudo del colegio" style="width:40px; height:40px; object-fit:cover; border-radius:50%; background:#fff;">
            <span>EcoFuturo</span>
        </div>
    </div>

    <div class="menu-ingreso">
        <button class="btn-ingreso" onclick="alternarMenu()">Ingresar ▾</button>
        <div class="lista-desplegable" id="listaIngreso">
            <a href="vistas/autenticacion/formularioEstudianteInfo.php">🎓 Soy Estudiante</a>
            <a href="vistas/autenticacion/formularioProfesor.php">🍎 Soy Profesor</a>
            <a href="vistas/admin/loginAdmin.php">🛠️ Soy Administrador</a>
            <a href="vistas/autenticacion/login.php">👤 Iniciar Sesión</a>
        </div>
    </div>
</header>

<?php if ($mostrarErrorCredenciales): ?>
    <div class="alerta-login" role="alert">Usuario, contraseña o rol incorrectos.</div>
<?php endif; ?>
 
<!-- ===== HERO ===== -->
<div class="hero">
    <h1><img src="img/logo-eco.svg?v=20261025-2" alt="" class="hero-logo">EcoFuturo</h1>
    <p>Educando hoy para proteger el planeta de mañana. Un espacio donde estudiantes y profesores construyen juntos una cultura ambiental sostenible.</p>
</div>
 
<!-- ===== QUIÉNES SOMOS ===== -->
<section>
    <h2 class="titulo-seccion">¿Quiénes somos?</h2>
    <div class="quienes-somos">
        <img src="img/quienes-somos.jpg" alt="Naturaleza">
        <div class="quienes-somos-texto">
            <h3>Una comunidad comprometida con el planeta</h3>
            <p>
                EcoFuturo es una iniciativa educativa creada para acercar a los jóvenes y docentes
                al cuidado del medio ambiente. A través de actividades prácticas, contenido interactivo
                y proyectos colaborativos, buscamos formar una generación consciente de su impacto
                en el planeta y capaz de generar cambios reales en su entorno escolar y comunidad.
            </p>
        </div>
    </div>
</section>
 
<!-- ===== NUESTRO PROPÓSITO ===== -->
<section class="proposito">
    <h2 class="titulo-seccion">Nuestro propósito</h2>
    <div class="tarjetas-proposito">
        <div class="tarjeta">
            <div class="icono">🌍</div>
            <h4>Concientizar</h4>
            <p>Sensibilizar a estudiantes y profesores sobre el cuidado del medio ambiente y el uso responsable de los recursos.</p>
        </div>
        <div class="tarjeta">
            <div class="icono">♻️</div>
            <h4>Educar</h4>
            <p>Brindar herramientas y conocimientos prácticos sobre reciclaje, ahorro de agua y energías limpias.</p>
        </div>
        <div class="tarjeta">
            <div class="icono">🤝</div>
            <h4>Involucrar</h4>
            <p>Promover la participación activa de la comunidad educativa en proyectos ambientales reales.</p>
        </div>
        <div class="tarjeta">
            <div class="icono">🌱</div>
            <h4>Transformar</h4>
            <p>Impulsar hábitos sostenibles que trasciendan del aula hacia el hogar y la comunidad.</p>
        </div>
    </div>
</section>
 
<!-- ===== FORMAS DE APRENDIZAJE ===== -->
<section>
    <h2 class="titulo-seccion">Formas de aprendizaje</h2>
    <div class="aprendizaje-grid">
        <div class="aprendizaje-tarjeta">
            <img src="img/talleres.jpg" alt="Talleres prácticos">
            <div class="aprendizaje-info">
                <h4>Talleres prácticos</h4>
                <p>Actividades presenciales de reciclaje, siembra y reutilización de materiales.</p>
            </div>
        </div>
        <div class="aprendizaje-tarjeta">
            <img src="img/interactivo.jpg" alt="Contenido interactivo">
            <div class="aprendizaje-info">
                <h4>Contenido interactivo</h4>
                <p>Videos, juegos y material digital pensado para aprender de forma dinámica.</p>
            </div>
        </div>
        <div class="aprendizaje-tarjeta">
            <img src="img/proyectos.jpg" alt="Proyectos colaborativos">
            <div class="aprendizaje-info">
                <h4>Proyectos colaborativos</h4>
                <p>Estudiantes y profesores trabajan juntos en soluciones ambientales para su colegio.</p>
            </div>
        </div>
        <div class="aprendizaje-tarjeta">
            <img src="img/charlas.jpg" alt="Charlas y capacitaciones">
            <div class="aprendizaje-info">
                <h4>Charlas y capacitaciones</h4>
                <p>Espacios formativos con expertos en sostenibilidad y educación ambiental.</p>
            </div>
        </div>
    </div>
</section>
 
<!-- ===== PIE DE PÁGINA ===== -->
<footer>
    &copy; <?php echo date("Y"); ?> EcoFuturo — Sembrando conciencia ambiental 🌿
</footer>
 
<script>
    function alternarMenu() {
        document.getElementById('listaIngreso').classList.toggle('activo');
    }
 
    // Cierra el menú si se hace clic fuera de él
    window.addEventListener('click', function (e) {
        const menu = document.querySelector('.menu-ingreso');
        const lista = document.getElementById('listaIngreso');
        if (!menu.contains(e.target)) {
            lista.classList.remove('activo');
        }
    });
</script>
 
</body>
</html>