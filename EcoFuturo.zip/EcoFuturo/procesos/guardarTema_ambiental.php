<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Location: profesor/guardar_tema.php', true, 307);
} else {
    header('Location: ../vistas/profesor/crearTema.php');
}
exit();