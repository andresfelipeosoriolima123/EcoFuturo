<?php
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../datos/UsuarioDAO.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../vistas/admin/loginAdmin.php');
    exit();
}

$correo = trim($_POST['correo'] ?? '');
$password = $_POST['password'] ?? '';
$usuario = (new UsuarioDAO())->buscarPorLoginORCorreo($correo, 1);

if (!$usuario || !password_verify($password, $usuario['password'])) {
    header('Location: ../../vistas/admin/loginAdmin.php?error=1');
    exit();
}

session_regenerate_id(true);
$_SESSION['id_usuario'] = $usuario['id_usuario'];
$_SESSION['nombre'] = $usuario['nombre'];
$_SESSION['usuario'] = $usuario['usuario_login'];
$_SESSION['id_rol'] = 1;

header('Location: ../../vistas/admin/indexAdmin.php');
exit();