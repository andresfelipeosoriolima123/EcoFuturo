<?php
require_once __DIR__ . '/../../config/auth.php';
requireRole(1);
require_once __DIR__ . '/../../datos/UsuarioDAO.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../vistas/admin/indexAdmin.php');
    exit();
}

$id_usuario = filter_input(INPUT_POST, 'id_usuario', FILTER_VALIDATE_INT);
$nombre = trim((string) filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_SPECIAL_CHARS));
$correo = trim((string) filter_input(INPUT_POST, 'correo', FILTER_SANITIZE_EMAIL));

if (!$id_usuario || $nombre === '' || $correo === '') {
    header('Location: ../../vistas/admin/indexAdmin.php?error=datos_invalidos');
    exit();
}

$usuarioDAO = new UsuarioDAO();
$usuario = $usuarioDAO->obtenerUsuarioPorId($id_usuario);

if (!$usuario) {
    header('Location: ../../vistas/admin/indexAdmin.php?error=usuario_no_encontrado');
    exit();
}

if ($usuario['id_rol'] == 3) {
    $documento = trim((string) filter_input(INPUT_POST, 'documento', FILTER_SANITIZE_SPECIAL_CHARS));
    $grado = trim((string) filter_input(INPUT_POST, 'grado', FILTER_SANITIZE_SPECIAL_CHARS));
    $curso = trim((string) filter_input(INPUT_POST, 'curso', FILTER_SANITIZE_SPECIAL_CHARS));

    if ($documento === '' || $grado === '' || $curso === '' || !preg_match('/^[\p{L}\s]+$/u', $grado)) {
        header('Location: ../../vistas/admin/indexAdmin.php?error=datos_invalidos');
        exit();
    }

    $exito = $usuarioDAO->actualizarEstudiante($id_usuario, $nombre, $correo, $documento, $grado, $curso);
} elseif ($usuario['id_rol'] == 2) {
    $documento = trim((string) filter_input(INPUT_POST, 'documento', FILTER_SANITIZE_SPECIAL_CHARS));
    $telefono = trim((string) filter_input(INPUT_POST, 'telefono', FILTER_SANITIZE_SPECIAL_CHARS));
    $curso = trim((string) filter_input(INPUT_POST, 'curso', FILTER_SANITIZE_SPECIAL_CHARS));

    if ($documento === '' || $telefono === '' || !preg_match('/^[0-9]+$/', $curso)) {
        header('Location: ../../vistas/admin/indexAdmin.php?error=datos_invalidos');
        exit();
    }

    $exito = $usuarioDAO->actualizarProfesor($id_usuario, $nombre, $correo, $documento, $telefono, $curso);
} else {
    header('Location: ../../vistas/admin/indexAdmin.php?error=rol_no_soportado');
    exit();
}

if ($exito) {
    header('Location: ../../vistas/admin/indexAdmin.php?exito=editado');
} else {
    header('Location: ../../vistas/admin/indexAdmin.php?error=actualizacion');
}
exit();
