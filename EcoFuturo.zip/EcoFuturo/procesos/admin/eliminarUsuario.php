<?php
// procesos/admin/eliminarUsuario.php
// Se comunica con: vistas/admin/indexAdmin.php
require_once __DIR__ . '/../../config/auth.php';
requireRole(1);
require_once __DIR__ . '/../../datos/UsuarioDAO.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../vistas/admin/indexAdmin.php');
    exit();
}

$id_usuario = filter_input(INPUT_POST, 'id_usuario', FILTER_VALIDATE_INT);

if (!$id_usuario) {
    header('Location: ../../vistas/admin/indexAdmin.php?error=1');
    exit();
}

$usuarioDAO = new UsuarioDAO();
$exito = $usuarioDAO->eliminarUsuario($id_usuario);

if ($exito) {
    header('Location: ../../vistas/admin/indexAdmin.php?exito=eliminado');
} else {
    header('Location: ../../vistas/admin/indexAdmin.php?error=1');
}
exit();
