<?php
require_once __DIR__ . '/../../config/auth.php';
requireRole(1);
require_once __DIR__ . '/../../datos/UsuarioDAO.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../vistas/admin/indexAdmin.php');
    exit();
}

$id_usuario = filter_input(INPUT_POST, 'id_usuario', FILTER_VALIDATE_INT);
$cuenta_activa = filter_input(INPUT_POST, 'cuenta_activa', FILTER_VALIDATE_INT);

if (!$id_usuario || ($cuenta_activa !== 0 && $cuenta_activa !== 1)) {
    header('Location: ../../vistas/admin/indexAdmin.php?error=datos_invalidos');
    exit();
}

$usuarioDAO = new UsuarioDAO();
if (!$usuarioDAO->actualizarEstadoCuenta($id_usuario, $cuenta_activa)) {
    header('Location: ../../vistas/admin/indexAdmin.php?error=estado_usuario');
    exit();
}

header('Location: ../../vistas/admin/indexAdmin.php?exito=estado_actualizado');
exit();
