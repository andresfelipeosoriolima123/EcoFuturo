<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(3);
require_once __DIR__ . '/../../config/conexionBDD.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['enviar_actividad'])) {
    header('Location: ../../vistas/estudiante/actividadesEstudiante.php');
    exit();
}

$conexion = ConexionBDD::getInstancia();
$idUsuario = (int) ($_SESSION['id_usuario'] ?? 0);
$nombreArchivo = null;
$nombreArchivoOriginal = null;
$rutaArchivo = null;

try {
    $actividadId = filter_var($_POST['actividad_id'] ?? 0, FILTER_VALIDATE_INT);
    $respuestaTexto = trim($_POST['respuesta_texto'] ?? '');
    if (!$actividadId || $respuestaTexto === '') {
        throw new InvalidArgumentException('Selecciona una actividad y escribe una respuesta.');
    }

    $stmtEstudiante = $conexion->prepare('SELECT id_estudiante FROM estudiantes WHERE id_usuario = ?');
    $stmtEstudiante->execute([$idUsuario]);
    $idEstudiante = $stmtEstudiante->fetchColumn();
    if (!$idEstudiante) {
        throw new RuntimeException('No se encontró el perfil del estudiante.');
    }

    $stmtActividad = $conexion->prepare("SELECT fecha_limite, permite_retraso,
                                                (fecha_limite IS NOT NULL AND NOW() > fecha_limite) AS plazo_vencido
                                         FROM actividad WHERE actividad_id = ? AND id_tema IS NOT NULL");
    $stmtActividad->execute([$actividadId]);
    $datosActividad = $stmtActividad->fetch(PDO::FETCH_ASSOC);
    if (!$datosActividad) {
        throw new InvalidArgumentException('La actividad seleccionada ya no está disponible.');
    }
    if ((int) $datosActividad['plazo_vencido'] === 1 && (int) $datosActividad['permite_retraso'] !== 1) {
        throw new InvalidArgumentException('El plazo venció y el profesor no acepta entregas con retraso.');
    }
    $entregaConRetraso = (int) $datosActividad['plazo_vencido'];

    $errorSubida = $_FILES['archivo_respuesta']['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($errorSubida !== UPLOAD_ERR_NO_FILE && $errorSubida !== UPLOAD_ERR_OK) {
        throw new InvalidArgumentException('No se pudo recibir el archivo adjunto.');
    }

    if ($errorSubida === UPLOAD_ERR_OK) {
        if ($_FILES['archivo_respuesta']['size'] > 5 * 1024 * 1024) {
            throw new InvalidArgumentException('El archivo supera el límite de 5 MB.');
        }

        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['archivo_respuesta']['tmp_name']);
        $extensionesPermitidas = [
            'application/pdf' => 'pdf',
            'text/plain' => 'txt',
            'image/jpeg' => 'jpg',
            'image/png' => 'png'
        ];
        if (!isset($extensionesPermitidas[$mime])) {
            throw new InvalidArgumentException('Adjunta un archivo PDF, TXT, JPG o PNG.');
        }

        $directorioSubida = __DIR__ . '/../../uploads/';
        if (!is_dir($directorioSubida) && !mkdir($directorioSubida, 0775, true) && !is_dir($directorioSubida)) {
            throw new RuntimeException('No se pudo preparar la carpeta para el archivo.');
        }

        $nombreArchivo = 'entrega_' . $idEstudiante . '_' . $actividadId . '_' . bin2hex(random_bytes(8)) . '.' . $extensionesPermitidas[$mime];
        $nombreArchivoOriginal = basename(str_replace('\\', '/', (string) $_FILES['archivo_respuesta']['name']));
        if ($nombreArchivoOriginal === '' || strlen($nombreArchivoOriginal) > 255) {
            throw new InvalidArgumentException('El nombre del archivo no es válido o supera los 255 bytes.');
        }

        $rutaArchivo = $directorioSubida . $nombreArchivo;
        if (!move_uploaded_file($_FILES['archivo_respuesta']['tmp_name'], $rutaArchivo)) {
            throw new RuntimeException('No se pudo guardar el archivo adjunto.');
        }
    }

    $stmtEntrega = $conexion->prepare("INSERT INTO ecoformularios
        (actividad_id, id_estudiante, respuesta_texto, archivo_respuesta, nombre_archivo_original, fecha_entrega, entrega_con_retraso)
        VALUES (?, ?, ?, ?, ?, NOW(), ?)
        ON DUPLICATE KEY UPDATE
            respuesta_texto = VALUES(respuesta_texto),
            archivo_respuesta = COALESCE(VALUES(archivo_respuesta), archivo_respuesta),
            nombre_archivo_original = COALESCE(VALUES(nombre_archivo_original), nombre_archivo_original),
            puntos_obtenidos = 0,
            observaciones_profesor = NULL,
            fecha_entrega = NOW(),
            entrega_con_retraso = VALUES(entrega_con_retraso)");
    $stmtEntrega->execute([
        $actividadId,
        $idEstudiante,
        $respuestaTexto,
        $nombreArchivo,
        $nombreArchivoOriginal,
        $entregaConRetraso
    ]);

    header('Location: ../../vistas/estudiante/actividadesEstudiante.php?msj=entrega_guardada&retraso=' . $entregaConRetraso);
    exit();
} catch (Throwable $e) {
    if ($rutaArchivo && is_file($rutaArchivo)) {
        unlink($rutaArchivo);
    }

    $_SESSION['error_entrega'] = $e instanceof InvalidArgumentException
        ? $e->getMessage()
        : 'No se pudo guardar la entrega. Intenta nuevamente.';
    header('Location: ../../vistas/estudiante/actividadesEstudiante.php');
    exit();
}