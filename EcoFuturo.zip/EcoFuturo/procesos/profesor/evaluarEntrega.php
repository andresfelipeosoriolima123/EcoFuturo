<?php
// procesos/evaluarEntrega.php - Guarda la nota asignada por el docente
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

require_once __DIR__ . '/../../config/conexionBDD.php';
$conexion = ConexionBDD::getInstancia();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_ecoformulario = filter_var($_POST['id_ecoformulario'] ?? 0, FILTER_VALIDATE_INT);
    $puntos_obtenidos     = filter_var($_POST['puntos_obtenidos'] ?? 0, FILTER_VALIDATE_INT);
    $observaciones_profesor = $_POST['observaciones_profesor'] ?? '';

    if ($id_ecoformulario && $puntos_obtenidos !== false && $puntos_obtenidos >= 0) {
        try {
            $conexion->beginTransaction();

            $sql = "UPDATE ecoformularios ef
                    INNER JOIN actividad c ON c.actividad_id = ef.actividad_id
                    INNER JOIN temas_ambientales t ON t.id_tema = c.id_tema
                    SET ef.puntos_obtenidos = :puntos,
                        ef.observaciones_profesor = :obs
                    WHERE ef.id_ecoformulario = :id
                      AND t.id_profesor = :profesor
                      AND :puntos_max <= c.puntaje_maximo";
            
            $stmt = $conexion->prepare($sql);
            $stmt->execute([
                'puntos' => $puntos_obtenidos,
                'puntos_max' => $puntos_obtenidos,
                'obs'    => $observaciones_profesor,
                'id'     => $id_ecoformulario,
                'profesor' => $_SESSION['id_usuario']
            ]);

            if ($stmt->rowCount() !== 1) {
                $stmtCheck = $conexion->prepare("SELECT 1
                                                 FROM ecoformularios ef
                                                 INNER JOIN actividad c ON c.actividad_id = ef.actividad_id
                                                 INNER JOIN temas_ambientales t ON t.id_tema = c.id_tema
                                                 WHERE ef.id_ecoformulario = ?
                                                   AND t.id_profesor = ?
                                                   AND ? <= c.puntaje_maximo");
                $stmtCheck->execute([$id_ecoformulario, $_SESSION['id_usuario'], $puntos_obtenidos]);
                if (!$stmtCheck->fetchColumn()) {
                    throw new RuntimeException('La calificación supera el puntaje máximo o la entrega no existe.');
                }
            }

            $stmtEntrega = $conexion->prepare("SELECT ef.id_estudiante, ef.actividad_id
                                               FROM ecoformularios ef
                                               INNER JOIN actividad c ON c.actividad_id = ef.actividad_id
                                               INNER JOIN temas_ambientales t ON t.id_tema = c.id_tema
                                               WHERE ef.id_ecoformulario = ?
                                                 AND t.id_profesor = ?");
            $stmtEntrega->execute([$id_ecoformulario, $_SESSION['id_usuario']]);
            $entrega = $stmtEntrega->fetch(PDO::FETCH_ASSOC);
            if (!$entrega) {
                throw new RuntimeException('No se encontró la entrega del estudiante.');
            }

            $stmtProgreso = $conexion->prepare("SELECT progreso_id
                                                FROM progreso
                                                WHERE id_estudiante = ? AND actividad_id = ?
                                                ORDER BY progreso_id DESC
                                                LIMIT 1");
            $stmtProgreso->execute([$entrega['id_estudiante'], $entrega['actividad_id']]);
            $idProgreso = $stmtProgreso->fetchColumn();

            if ($idProgreso) {
                $stmtGuardarProgreso = $conexion->prepare("UPDATE progreso
                                                           SET fecha = CURDATE(), puntaje = ?, estado = 'Completado'
                                                           WHERE progreso_id = ?");
                $stmtGuardarProgreso->execute([$puntos_obtenidos, $idProgreso]);
            } else {
                $stmtGuardarProgreso = $conexion->prepare("INSERT INTO progreso
                                                           (id_estudiante, actividad_id, fecha, puntaje, estado)
                                                           VALUES (?, ?, CURDATE(), ?, 'Completado')");
                $stmtGuardarProgreso->execute([
                    $entrega['id_estudiante'],
                    $entrega['actividad_id'],
                    $puntos_obtenidos
                ]);
            }

            $conexion->commit();

            header("Location: ../../vistas/profesor/evaluarEntregas.php?msj=nota_guardada");
            exit();
        } catch (Exception $e) {
            if ($conexion->inTransaction()) {
                $conexion->rollBack();
            }
            http_response_code(400);
            echo htmlspecialchars('Error al guardar la calificación: ' . $e->getMessage(), ENT_QUOTES, 'UTF-8');
            exit();
        }
    } else {
        http_response_code(400);
        exit('Los datos de calificación no son válidos.');
    }
} else {
    header("Location: ../../vistas/profesor/evaluarEntregas.php");
    exit();
}