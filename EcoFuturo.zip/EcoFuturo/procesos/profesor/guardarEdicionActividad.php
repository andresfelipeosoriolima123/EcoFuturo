<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

require_once __DIR__ . '/../../config/conexionBDD.php';
$conexion = ConexionBDD::getInstancia();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../vistas/profesor/gestionar_actividades.php');
    exit();
}

$actividad_id = filter_input(INPUT_POST, 'actividad_id', FILTER_VALIDATE_INT);
$titulo = trim((string) ($_POST['titulo_actividad'] ?? ''));
$descripcion = trim((string) ($_POST['instrucciones'] ?? ''));
$puntos = filter_input(INPUT_POST, 'puntaje_maximo', FILTER_VALIDATE_INT);
$fechaVencimientoInput = trim((string) ($_POST['fecha_vencimiento'] ?? ''));
$permiteRetraso = isset($_POST['permite_retraso']) ? 1 : 0;

if (!$actividad_id || $titulo === '' || $descripcion === '' || $puntos === false || $puntos === null || $puntos < 1 || $puntos > 50) {
    header('Location: ../../vistas/profesor/gestionar_actividades.php?error=datos_invalidos');
    exit();
}

$fechaVencimiento = null;
if ($fechaVencimientoInput !== '') {
    $fechaValidada = DateTime::createFromFormat('!Y-m-d\TH:i', $fechaVencimientoInput);
    $erroresFecha = DateTime::getLastErrors();
    if (!$fechaValidada || ($erroresFecha !== false && ($erroresFecha['warning_count'] > 0 || $erroresFecha['error_count'] > 0))) {
        header('Location: ../../vistas/profesor/gestionar_actividades.php?error=fecha_invalida');
        exit();
    }
    if ($fechaValidada->format('Y-m-d') < date('Y-m-d')) {
        header('Location: ../../vistas/profesor/gestionar_actividades.php?error=fecha_invalida');
        exit();
    }
    $fechaVencimiento = $fechaValidada->format('Y-m-d H:i:s');
}

try {
    $stmtNivel = $conexion->prepare("SELECT nivel_id FROM nivel ORDER BY ABS(puntos_minimos - ?), nivel_id LIMIT 1");
    $stmtNivel->execute([$puntos]);
    $nivelId = $stmtNivel->fetchColumn();
    if ($nivelId === false) {
        throw new RuntimeException('No hay niveles registrados para asignar a la actividad.');
    }

    $stmt = $conexion->prepare("UPDATE actividad a
                                INNER JOIN temas_ambientales t ON t.id_tema = a.id_tema
                                SET a.nombre = :titulo,
                                    a.descripcion = :descripcion,
                                    a.nivel_id = :nivel_id,
                                    a.titulo_actividad = :titulo_actividad,
                                    a.instrucciones = :instrucciones,
                                    a.puntaje_maximo = :puntos,
                                    a.fecha_limite = :fecha_limite,
                                    a.permite_retraso = :permite_retraso
                                WHERE a.actividad_id = :actividad_id AND t.id_profesor = :profesor");
    $stmt->execute([
        'titulo' => $titulo,
        'descripcion' => $descripcion,
        'nivel_id' => $nivelId,
        'titulo_actividad' => $titulo,
        'instrucciones' => $descripcion,
        'puntos' => $puntos,
        'fecha_limite' => $fechaVencimiento,
        'permite_retraso' => $permiteRetraso,
        'actividad_id' => $actividad_id,
        'profesor' => $_SESSION['id_usuario']
    ]);

    if ($stmt->rowCount() !== 1) {
        $stmtExiste = $conexion->prepare("SELECT 1
                                          FROM actividad a
                                          INNER JOIN temas_ambientales t ON t.id_tema = a.id_tema
                                          WHERE a.actividad_id = ? AND t.id_profesor = ?");
        $stmtExiste->execute([$actividad_id, $_SESSION['id_usuario']]);
        if (!$stmtExiste->fetchColumn()) {
            throw new RuntimeException('La actividad no se pudo actualizar.');
        }
    }

    header('Location: ../../vistas/profesor/gestionar_actividades.php?msj=actividad_actualizada');
    exit();
} catch (Exception $e) {
    header('Location: ../../vistas/profesor/gestionar_actividades.php?error=actualizacion');
    exit();
}
