<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

require_once __DIR__ . '/../../config/conexionBDD.php';
$conexion = ConexionBDD::getInstancia();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../vistas/profesor/evaluarEntregas.php');
    exit();
}

$id_ecoformulario = filter_input(INPUT_POST, 'id_ecoformulario', FILTER_VALIDATE_INT);
$puntos_obtenidos = filter_input(INPUT_POST, 'puntos_obtenidos', FILTER_VALIDATE_INT);
$observaciones_profesor = trim((string) ($_POST['observaciones_profesor'] ?? ''));

if (!$id_ecoformulario || $puntos_obtenidos === false || $puntos_obtenidos < 0) {
    header('Location: ../../vistas/profesor/evaluarEntregas.php?error=datos_invalidos');
    exit();
}

try {
    $stmt = $conexion->prepare("UPDATE ecoformularios ef
                                INNER JOIN actividad c ON c.actividad_id = ef.actividad_id
                                INNER JOIN temas_ambientales t ON t.id_tema = c.id_tema
                                SET ef.puntos_obtenidos = :puntos,
                                    ef.observaciones_profesor = :obs
                                WHERE ef.id_ecoformulario = :id_ecoformulario
                                  AND t.id_profesor = :profesor
                                  AND :puntos <= c.puntaje_maximo");
    $stmt->execute([
        'puntos' => $puntos_obtenidos,
        'obs' => $observaciones_profesor,
        'id_ecoformulario' => $id_ecoformulario,
        'profesor' => $_SESSION['id_usuario']
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException('La nota no pertenece a tu actividad o supera el puntaje máximo.');
    }

    header('Location: ../../vistas/profesor/evaluarEntregas.php?msj=nota_guardada');
    exit();
} catch (Exception $e) {
    header('Location: ../../vistas/profesor/evaluarEntregas.php?error=actualizacion');
    exit();
}
