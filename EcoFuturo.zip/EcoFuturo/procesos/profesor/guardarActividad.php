<?php
// procesos/profesor/guardarActividad.php - Procesamiento de inserción de actividades
session_start();
require_once __DIR__ . '/../../config/auth.php';
requireRole(2);

require_once __DIR__ . '/../../config/conexionBDD.php';
$conexion = ConexionBDD::getInstancia();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idTema = $_POST['id_tema'] ?? null;
    $titulo = trim($_POST['titulo_actividad'] ?? '');
    $descripcion = trim($_POST['instrucciones'] ?? '');
    $puntos = $_POST['puntaje_maximo'] ?? null;
    $fechaVencimientoInput = trim($_POST['fecha_vencimiento'] ?? '');
    $permiteRetraso = isset($_POST['permite_retraso']) ? 1 : 0;

    $idTema = filter_var($idTema, FILTER_VALIDATE_INT);
    $puntos = filter_var($puntos, FILTER_VALIDATE_INT);
    if (!$idTema || $titulo === '' || $descripcion === '' || $puntos === false || $puntos === null || $puntos < 1 || $puntos > 50) {
        echo "<script>
            alert('Completa los campos requeridos y usa un puntaje máximo entre 1 y 50.');
            window.history.back();
        </script>";
        exit;
    }

    $fechaVencimiento = null;
    if ($fechaVencimientoInput !== '') {
        $fechaValidada = DateTime::createFromFormat('!Y-m-d\TH:i', $fechaVencimientoInput);
        $erroresFecha = DateTime::getLastErrors();
        if (!$fechaValidada || ($erroresFecha !== false && ($erroresFecha['warning_count'] > 0 || $erroresFecha['error_count'] > 0))) {
            echo "<script>alert('La fecha de vencimiento no es válida.'); window.history.back();</script>";
            exit;
        }
        if ($fechaValidada->format('Y-m-d') < date('Y-m-d')) {
            echo "<script>alert('La fecha de vencimiento no puede ser anterior a hoy.'); window.history.back();</script>";
            exit;
        }
        $fechaVencimiento = $fechaValidada->format('Y-m-d H:i:s');
    }

    try {
        $idProfesor = (int) ($_SESSION['id_usuario'] ?? 0);
        $stmtTema = $conexion->prepare("SELECT 1 FROM temas_ambientales WHERE id_tema = ? AND id_profesor = ?");
        $stmtTema->execute([$idTema, $idProfesor]);
        if (!$stmtTema->fetchColumn()) {
            throw new RuntimeException('El tema no existe o no pertenece a tu cuenta.');
        }

        $stmtNivel = $conexion->prepare("SELECT nivel_id FROM nivel ORDER BY ABS(puntos_minimos - ?), nivel_id LIMIT 1");
        $stmtNivel->execute([$puntos]);
        $nivelId = $stmtNivel->fetchColumn();
        if ($nivelId === false) {
            throw new RuntimeException('No hay niveles registrados para asignar a la actividad.');
        }

        $stmt = $conexion->prepare("INSERT INTO actividad
            (nombre, descripcion, nivel_id, id_tema, titulo_actividad, instrucciones, puntaje_maximo, fecha_limite, permite_retraso)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$titulo, $descripcion, $nivelId, $idTema, $titulo, $descripcion, $puntos, $fechaVencimiento, $permiteRetraso]);

        header('Location: ../../vistas/profesor/indexProfesor.php?msj=actividad_guardada');
        exit;

    } catch (Exception $e) {
        echo "<script>
            alert('Error al registrar la actividad: " . addslashes($e->getMessage()) . "');
            window.history.back();
        </script>";
        exit;
    }
} else {
    header("Location: ../../vistas/profesor/indexProfesor.php");
    exit;
}
?>