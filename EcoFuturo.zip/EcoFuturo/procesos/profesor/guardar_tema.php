<?php
// procesos/profesor/guardar_tema.php
session_start();

require_once __DIR__ . '/../../datos/TemaDAO.php';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/conexionBDD.php';

requireRole(2);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        $db = ConexionBDD::getInstancia();
        $id_profesor = (int) ($_SESSION['id_usuario'] ?? 0);
        $stmtProfesor = $db->prepare("SELECT 1 FROM profesores WHERE id_usuario = ?");
        $stmtProfesor->execute([$id_profesor]);
        if (!$stmtProfesor->fetchColumn()) {
            throw new RuntimeException('La cuenta no tiene un perfil de profesor activo.');
        }

        // Capturar datos del formulario
        $titulo      = trim($_POST['titulo_tema'] ?? $_POST['titulo'] ?? $_POST['nombre_tema'] ?? '');
        $categoria   = trim($_POST['categoria'] ?? $_POST['categoria_tema'] ?? 'Taller');
        $descripcion = trim($_POST['descripcion'] ?? $_POST['descripcion_tema'] ?? $_POST['objetivo'] ?? '');
        $categoriasValidas = ['Charla', 'Taller', 'Proyecto', 'Actividad Interactiva'];
        
        if (!empty($titulo) && !empty($descripcion) && in_array($categoria, $categoriasValidas, true)) {
            
            $temaDAO = new TemaDAO();
            $guardado = $temaDAO->insertarTema($id_profesor, $titulo, $categoria, $descripcion);

            if ($guardado) {
                header('Location: ../../vistas/profesor/indexProfesor.php?msj=tema_guardado');
                exit();
            } else {
                echo "<script>
                        alert('El método insertarTema devolvió falso.');
                        window.history.back();
                      </script>";
            }

        } else {
            echo "<script>
                    alert('Por favor completa el título, la descripción y selecciona una categoría válida.');
                    window.history.back();
                  </script>";
        }

    } catch (Exception $e) {
        $errorMensaje = addslashes($e->getMessage());
        echo "<script>
                alert('Error de BD: $errorMensaje');
                window.history.back();
              </script>";
    }

} else {
    header("Location: ../../vistas/profesor/indexProfesor.php");
    exit();
}
?>