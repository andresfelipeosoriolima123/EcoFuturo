<?php
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../datos/UsuarioDAO.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $user_input = trim($_POST['usuario'] ?? '');
    $password   = $_POST['password'] ?? '';
    $rol_input  = (int)($_POST['rol'] ?? 0);

    $usuarioDAO = new UsuarioDAO();
    $usuario = $usuarioDAO->buscarPorLoginORCorreo($user_input, $rol_input);

    if ($usuario && password_verify($password, $usuario['password'])) {
        session_regenerate_id(true);
        
        $_SESSION['id_usuario'] = $usuario['id_usuario'];
        $_SESSION['nombre']     = $usuario['nombre'];
        $_SESSION['usuario']    = $usuario['usuario_login'];
        $_SESSION['id_rol']     = $usuario['id_rol'];

        if ($usuario['id_rol'] == 2) {
            header("Location: ../../vistas/profesor/indexProfesor.php");
            exit();
        } else if ($usuario['id_rol'] == 3) {
            header("Location: ../../vistas/estudiante/indexEstudiante.php");
            exit();
        }

    } else {
        $usuarioInactivo = $usuarioDAO->buscarCuentaInactivaPorLoginORCorreo($user_input, $rol_input);
        if ($usuarioInactivo && password_verify($password, $usuarioInactivo['password'])) {
            header("Location: ../../index.php?error=credenciales");
            exit();
        }

                header("Location: ../../vistas/autenticacion/login.php?error=credenciales");
                exit();
    }

} else {
    header("Location: ../../vistas/autenticacion/login.php");
    exit();
}
?>
