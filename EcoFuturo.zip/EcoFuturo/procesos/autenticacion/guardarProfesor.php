<?php
require_once __DIR__ . '/../../datos/UsuarioDAO.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $usuarioDAO = new UsuarioDAO();

    // Captura y sanitización de datos
    $nombre        = trim($_POST['nombre'] ?? '');
    $documento     = trim($_POST['documento'] ?? '');
    $correo        = trim($_POST['correo'] ?? '');
    $telefono      = trim($_POST['telefono'] ?? '');
    $curso         = trim($_POST['curso'] ?? '');
    $usuario_login = trim($_POST['usuario_login'] ?? '');
    $password_raw  = $_POST['password'] ?? '';
    if (!isset($_POST['acepto'])) {
        echo "<script>alert('Debes aceptar participar como docente aliado de EcoFuturo para registrarte.'); window.history.back();</script>";
        exit();
    }

    // --- VALIDACIONES DE FORMATO ESTRICTO ---
    if ($correo === '' || !filter_var($correo, FILTER_VALIDATE_EMAIL)
        || $usuario_login === '' || $password_raw === '') {
        echo "<script>alert('Completa todos los campos con datos válidos.'); window.history.back();</script>";
        exit();
    }
    
    // 1. Validar que el nombre completo solo tenga letras (incluyendo tildes y Ñ) y espacios
    if (!preg_match("/^[A-Za-zñÑáéíóúÁÉÍÓÚ\s]+$/", $nombre)) {
        echo "<script>
                alert('Error: El nombre completo solo debe contener letras.');
                window.history.back();
              </script>";
        exit();
    }

    // 2. Validar que el documento de identidad solo tenga números
    if (!preg_match("/^[0-9]+$/", $documento)) {
        echo "<script>
                alert('Error: El documento de identidad solo debe contener números.');
                window.history.back();
              </script>";
        exit();
    }

    // 3. Validar que el teléfono de contacto solo tenga números
    if (!preg_match("/^[0-9]+$/", $telefono)) {
        echo "<script>
                alert('Error: El teléfono de contacto solo debe contener números.');
                window.history.back();
              </script>";
        exit();
    }

    // 4. Validar que el curso asignado solo tenga números
    if (!preg_match("/^[0-9]+$/", $curso)) {
        echo "<script>
                alert('Error: El curso asignado solo debe contener números.');
                window.history.back();
              </script>";
        exit();
    }

    // Encriptar la contraseña de forma segura
    $password = password_hash($password_raw, PASSWORD_BCRYPT);

    $id_usuario = $usuarioDAO->registrarProfesorCompleto(
        $nombre,
        $correo,
        $usuario_login,
        $password,
        $documento,
        $telefono,
        $curso
    );

    if ($id_usuario) {
                header('Location: ../../vistas/autenticacion/login.php?registro=profesor');
        exit();
    } else {
        echo "<script>
                alert('No se pudo registrar al profesor. Verifica que correo, usuario y documento no estén registrados.');
                window.history.back();
              </script>";
    }

} else {
    header("Location: ../../vistas/autenticacion/formularioProfesor.php");
    exit();
}
?>