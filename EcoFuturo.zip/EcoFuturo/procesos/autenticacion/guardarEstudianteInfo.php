<?php
require_once __DIR__ . '/../../datos/UsuarioDAO.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $usuarioDAO = new UsuarioDAO();

    // Captura y sanitización de campos del formulario
    $nombre         = trim($_POST['nombre'] ?? '');
    $documento      = trim($_POST['documento'] ?? '');
    $correo         = trim($_POST['correo'] ?? '');
    $grado          = trim($_POST['grado'] ?? '');
    $curso          = trim($_POST['curso'] ?? '');
    $usuario_login  = trim($_POST['usuario_login'] ?? '');
    $password_raw   = $_POST['password'] ?? '';
    if (!isset($_POST['acepto'])) {
        echo "<script>alert('Debes aceptar participar como estudiante de EcoFuturo para registrarte.'); window.history.back();</script>";
        exit();
    }

    // 0. Validaciones estrictas de formato
    if ($correo === '' || !filter_var($correo, FILTER_VALIDATE_EMAIL)
        || $usuario_login === '' || $password_raw === '') {
        echo "<script>alert('Completa todos los campos con datos válidos.'); window.history.back();</script>";
        exit();
    }

    // Validar que el nombre solo tenga letras (incluyendo tildes y Ñ) y espacios
    if (!preg_match("/^[A-Za-zñÑáéíóúÁÉÍÓÚ\s]+$/", $nombre)) {
        echo "<script>
                alert('Error: El nombre completo solo debe contener letras.');
                window.history.back();
              </script>";
        exit();
    }

    if (!preg_match('/^[\p{L}\s]+$/u', $grado)) {
        echo "<script>
                alert('Error: El grado escolar debe escribirse con palabras y sin números.');
                window.history.back();
              </script>";
        exit();
    }

    // Validar que el documento de identidad solo tenga números
    if (!preg_match("/^[0-9]+$/", $documento)) {
        echo "<script>
                alert('Error: El documento de identidad solo debe contener números.');
                window.history.back();
              </script>";
        exit();
    }

    // Validar que el curso o grupo solo tenga números
    if (!preg_match("/^[0-9]+$/", $curso)) {
        echo "<script>
                alert('Error: El curso o grupo solo debe contener números.');
                window.history.back();
              </script>";
        exit();
    }

    // Encriptar la contraseña de forma segura
    $password = password_hash($password_raw, PASSWORD_BCRYPT);

    $id_usuario = $usuarioDAO->registrarEstudianteCompleto(
        $nombre,
        $correo,
        $usuario_login,
        $password,
        $documento,
        $grado,
        $curso
    );

    if ($id_usuario) {
                header('Location: ../../vistas/autenticacion/login.php?registro=estudiante');
        exit();
    } else {
        echo "<script>
                alert('No se pudo registrar el estudiante. Verifica que el correo, usuario y documento no estén registrados.');
                window.history.back();
              </script>";
    }

} else {
    header("Location: ../../vistas/autenticacion/formularioEstudianteInfo.php");
    exit();
}
?>