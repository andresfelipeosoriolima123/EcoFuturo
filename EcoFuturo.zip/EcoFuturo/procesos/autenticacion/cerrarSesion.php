<?php
// procesos/autenticacion/cerrarSesion.php
// Se comunica con: cualquier vista que tenga un botón "Salir" (admin, profesor, estudiante)
session_start();
$_SESSION = [];
session_destroy();
header("Location: ../../index.php");
exit();
