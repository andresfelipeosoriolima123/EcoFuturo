<?php
require_once __DIR__ . '/../config/auth.php';
requireRole(1);
require_once __DIR__ . '/../datos/UsuarioDAO.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../vistas/admin/indexAdmin.php');
    exit();
}

$id_usuario = filter_input(INPUT_POST, 'id_usuario', FILTER_VALIDATE_INT);
$eliminado = $id_usuario && (new UsuarioDAO())->eliminarUsuario($id_usuario);

header('Location: ../vistas/admin/indexAdmin.php?' . ($eliminado ? 'exito=eliminado' : 'error=1'));
exit();