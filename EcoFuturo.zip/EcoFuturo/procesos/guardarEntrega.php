<?php
// Compatibilidad con la ruta anterior de entrega.
require __DIR__ . '/estudiante/guardarEntrega.php';